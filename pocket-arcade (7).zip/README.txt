POCKET ARCADE
=============
A static website with 31 original browser games. No server, database, or
build step is needed. It is just HTML, CSS, and JavaScript files.

WHAT'S IN THE FOLDER
- index.html ........ homepage (game grid, search, category filters)
- <game>.html ....... one page per game (for example snake.html, block-escape.html)
- games.js .......... the code for every game
- style.css ......... shared styles
- sitemap.xml ....... list of all pages, for Google
- robots.txt ........ tells search engines they may crawl the site
- README.txt ........ this file

GAMES
Arcade/Puzzle: Snake, Tic-Tac-Toe, Memory Match, Brick Breaker, Flap Hop,
  Merge Tiles, Sweeper, Paddle Duel, Four in a Row, Mole Pop, Color Echo,
  Word Guess, Light Switch, Slide Puzzle, Dodge Dash, Star Blaster
Puzzle: Block Escape (sliding block puzzle, 275 levels; Self-paced, Timed, Speed)
Shooters: Neon Strike, Void Raider, Crimson Skies, Deep Current, Cyber Arena,
  Ghost Hunt, Last Bastion, Rooftop Defense, Alien Wave, Galaxy Guard
Battle royale with building: Island Royale, Frost Royale, Desert Rush, Build Fight
All games are original code written for this site. They are single-player.

TRY IT ON YOUR COMPUTER
Open index.html in a browser. Everything works without internet (the web
font is optional and falls back to a system font).

PUT IT ON YOUR WEBSITE
1. Keep ALL files together in the same folder. The pages load style.css and
   games.js from beside them.
2. Upload the contents of this folder to the ROOT of a static host, for
   example Cloudflare Pages, Netlify (drag the folder onto app.netlify.com/drop),
   or GitHub Pages.
3. Connect your domain in the host's settings and copy the DNS records it
   gives you into your domain registrar.
4. Open yourdomain/sitemap.xml in a browser to confirm it loads.

YOUR DOMAIN
The domain test-quiz-100.org is written into sitemap.xml, robots.txt, and the
"canonical" and "og:url" tags in every .html file. If you use a different
domain, open the files in a text editor and find-and-replace
test-quiz-100.org with your domain.

GETTING ON GOOGLE
1. Go to search.google.com/search-console and add your domain. Verify it with
   the DNS record Google gives you.
2. Open Sitemaps and submit: https://YOUR-DOMAIN/sitemap.xml
3. In URL Inspection, paste your homepage and click "Request indexing".
Indexing usually takes days to weeks. Ranking for popular searches takes longer.

ADDING OR CHANGING GAMES
- Each game is a function in games.js, started from its own .html page.
- To add a game: write the function in games.js, copy one of the game .html
  files, change the title, description, canonical URL, and the function name
  in the last <script> line, then add a tile to index.html and a <url> entry
  to sitemap.xml.

SAVED DATA
Block Escape saves progress and best scores in the visitor's own browser
(localStorage). Nothing is sent to any server.

NOTES
- The games were tested for errors in a script harness, not on every device.
  Play each one after you upload it.
- Real online multiplayer would need a server, which this site does not have.
