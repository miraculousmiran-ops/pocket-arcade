const $=s=>document.querySelector(s);
function snake(el){
  el.innerHTML='<canvas width="360" height="360" tabindex="0"></canvas><div class="hud">Score <b id="sc">0</b><button id="rs">Restart</button></div><div class="pad"><button data-d="U" aria-label="Up">▲</button><button data-d="L" aria-label="Left">◀</button><button data-d="D" aria-label="Down">▼</button><button data-d="R" aria-label="Right">▶</button></div>';
  const c=el.querySelector('canvas'),x=c.getContext('2d'),N=18,S=20,V={U:[0,-1],D:[0,1],L:[-1,0],R:[1,0]},O={U:'D',D:'U',L:'R',R:'L'};
  let s,d,nd,f,sc,over,t;
  const at=(p,a)=>p[0]==a[0]&&p[1]==a[1];
  function place(){do{f=[Math.random()*N|0,Math.random()*N|0]}while(s.some(p=>at(p,f)))}
  function init(){s=[[9,9],[8,9],[7,9]];d=nd='R';sc=0;over=false;$('#sc').textContent=0;place();draw()}
  function step(){
    if(over)return;d=nd;const h=[s[0][0]+V[d][0],s[0][1]+V[d][1]];
    if(h[0]<0||h[1]<0||h[0]>=N||h[1]>=N||s.some(p=>at(p,h))){over=true;draw();return}
    s.unshift(h);
    if(at(h,f)){sc++;$('#sc').textContent=sc;place()}else s.pop();
    draw();
  }
  function draw(){
    x.fillStyle='#1b2250';x.fillRect(0,0,360,360);
    x.fillStyle='#ff6a3d';x.beginPath();x.arc(f[0]*S+10,f[1]*S+10,7,0,7);x.fill();
    x.fillStyle='#14a39a';s.forEach((p,i)=>{x.fillStyle=i?'#14a39a':'#7ff0e6';x.fillRect(p[0]*S+1,p[1]*S+1,S-2,S-2)});
    if(over){x.fillStyle='rgba(0,0,0,.6)';x.fillRect(0,0,360,360);x.fillStyle='#fff';x.font='800 30px sans-serif';x.textAlign='center';x.fillText('Game over',180,175);x.font='16px sans-serif';x.fillText('Press Restart to play again',180,205)}
  }
  const dir=k=>{if(k&&k!==O[d])nd=k};
  const kd=e=>{const k={ArrowUp:'U',w:'U',ArrowDown:'D',s:'D',ArrowLeft:'L',a:'L',ArrowRight:'R',d:'R'}[e.key];if(k){e.preventDefault();dir(k)}};
  document.addEventListener('keydown',kd);
  el.querySelectorAll('.pad button').forEach(b=>b.onclick=()=>dir(b.dataset.d));
  $('#rs').onclick=init;
  let tx,ty;
  c.addEventListener('touchstart',e=>{tx=e.touches[0].clientX;ty=e.touches[0].clientY},{passive:true});
  c.addEventListener('touchend',e=>{const dx=e.changedTouches[0].clientX-tx,dy=e.changedTouches[0].clientY-ty;if(Math.max(Math.abs(dx),Math.abs(dy))<20)return;dir(Math.abs(dx)>Math.abs(dy)?(dx>0?'R':'L'):(dy>0?'D':'U'))});
  init();t=setInterval(step,110);
  return()=>{clearInterval(t);document.removeEventListener('keydown',kd)};
}
function ttt(el){
  const L=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
  let b,msg,done,sc={X:0,O:0,D:0};
  const win=b=>{for(const[a,c,d]of L)if(b[a]&&b[a]==b[c]&&b[a]==b[d])return b[a];return b.every(Boolean)?'D':null};
  function mm(b,p){const w=win(b);if(w)return w=='O'?1:w=='X'?-1:0;let best=p=='O'?-2:2;for(let i=0;i<9;i++)if(!b[i]){b[i]=p;const v=mm(b,p=='O'?'X':'O');b[i]='';best=p=='O'?Math.max(best,v):Math.min(best,v)}return best}
  function ai(){
    const free=[...b.keys()].filter(i=>!b[i]);let pick;
    if(Math.random()<.3)pick=free[Math.random()*free.length|0];
    else{let bv=-2;for(const i of free){b[i]='O';const v=mm(b,'X');b[i]='';if(v>bv){bv=v;pick=i}}}
    b[pick]='O';
  }
  function end(){const w=win(b);if(!w)return false;done=true;sc[w]++;msg=w=='X'?'You win!':w=='O'?'Computer wins.':'It\u2019s a draw.';return true}
  function init(){b=Array(9).fill('');msg='Your move.';done=false;draw()}
  function draw(){
    el.innerHTML=`<div class="hud">You ${sc.X} · Computer ${sc.O} · Draws ${sc.D}</div><div class="board t">${b.map((v,i)=>`<button class="cell" data-i="${i}" aria-label="Square ${i+1} ${v}">${v}</button>`).join('')}</div><div class="hud" aria-live="polite">${msg}</div><button id="rs">New game</button>`;
    el.querySelectorAll('.cell').forEach(c=>c.onclick=()=>{const i=+c.dataset.i;if(done||b[i])return;b[i]='X';if(!end()){ai();if(!end())msg='Your move.'}draw()});
    $('#rs').onclick=init;
  }
  init();return()=>{};
}
function memory(el){
  const E=['🚀','🌵','🍉','🎲','🐙','🎸','🧩','🍄'];
  let cards,up,done,moves,lock,timer;
  function init(){cards=[...E,...E].sort(()=>Math.random()-.5);up=[];done=new Set();moves=0;lock=false;draw()}
  function draw(){
    el.innerHTML=`<div class="hud" aria-live="polite">Moves <b>${moves}</b>${done.size==16?' · You won! 🎉':''}</div><div class="board m">${cards.map((e,i)=>{const o=up.includes(i)||done.has(i);return`<button class="cell ${done.has(i)?'ok':o?'up':''}" data-i="${i}" aria-label="${o?e:'Hidden card'}">${o?e:''}</button>`}).join('')}</div><button id="rs">New game</button>`;
    el.querySelectorAll('.cell').forEach(c=>c.onclick=()=>{
      const i=+c.dataset.i;if(lock||up.includes(i)||done.has(i))return;
      up.push(i);
      if(up.length==2){
        moves++;
        if(cards[up[0]]==cards[up[1]]){up.forEach(k=>done.add(k));up=[];draw()}
        else{lock=true;draw();timer=setTimeout(()=>{up=[];lock=false;draw()},800)}
      }else draw();
    });
    $('#rs').onclick=()=>{clearTimeout(timer);init()};
  }
  init();return()=>clearTimeout(timer);
}
function breakout(el){
  el.innerHTML='<canvas width="360" height="420" tabindex="0"></canvas><div class="hud">Score <b id="sc">0</b> Lives <b id="lv">3</b><button id="rs">Restart</button></div><p class="empty">Move with the mouse, your finger, or the arrow keys.</p>';
  const c=el.querySelector('canvas'),x=c.getContext('2d'),W=360,H=420,PW=70,R=6,cols=8,rows=5,BW=W/cols,BH=18,K={};
  const cl=['#ff6a3d','#ffb199','#14a39a','#7ff0e6','#c5b8ff'];
  let px,bx,by,vx,vy,br,sc,lv,run,raf;
  function serve(){bx=W/2;by=H-60;vx=Math.random()<.5?-2.5:2.5;vy=-3.5}
  function init(){px=W/2-PW/2;sc=0;lv=3;br=[];for(let r=0;r<rows;r++)for(let k=0;k<cols;k++)br.push({x:k*BW,y:50+r*BH,on:1,c:cl[r]});serve();$('#sc').textContent=0;$('#lv').textContent=3;run=true}
  function tick(){
    if(run){
      if(K.ArrowLeft||K.a)px-=6;if(K.ArrowRight||K.d)px+=6;px=Math.max(0,Math.min(W-PW,px));
      bx+=vx;by+=vy;
      if(bx<R||bx>W-R)vx=-vx;if(by<R)vy=-vy;
      if(vy>0&&by>H-30-R&&by<H-20&&bx>px&&bx<px+PW){vy=-Math.abs(vy);vx=(bx-(px+PW/2))/(PW/2)*4}
      for(const b of br)if(b.on&&bx>b.x&&bx<b.x+BW&&by>b.y&&by<b.y+BH){b.on=0;vy=-vy;sc++;$('#sc').textContent=sc;break}
      if(by>H){lv--;$('#lv').textContent=lv;if(lv<=0)run=false;else serve()}
      if(!br.some(b=>b.on))run=false;
    }
    draw();raf=requestAnimationFrame(tick);
  }
  function draw(){
    x.fillStyle='#1b2250';x.fillRect(0,0,W,H);
    br.forEach(b=>{if(b.on){x.fillStyle=b.c;x.fillRect(b.x+1,b.y+1,BW-2,BH-2)}});
    x.fillStyle='#fff';x.fillRect(px,H-30,PW,10);x.beginPath();x.arc(bx,by,R,0,7);x.fill();
    if(!run){x.fillStyle='rgba(0,0,0,.6)';x.fillRect(0,0,W,H);x.fillStyle='#fff';x.font='800 28px sans-serif';x.textAlign='center';x.fillText(lv>0?'You cleared it!':'Game over',W/2,H/2);x.font='15px sans-serif';x.fillText('Press Restart to play again',W/2,H/2+28)}
  }
  const kd=e=>{K[e.key]=1;if(e.key.startsWith('Arrow'))e.preventDefault()},ku=e=>{K[e.key]=0};
  document.addEventListener('keydown',kd);document.addEventListener('keyup',ku);
  c.addEventListener('pointermove',e=>{const r=c.getBoundingClientRect();px=Math.max(0,Math.min(W-PW,(e.clientX-r.left)*W/r.width-PW/2))});
  $('#rs').onclick=init;init();tick();
  return()=>{cancelAnimationFrame(raf);document.removeEventListener('keydown',kd);document.removeEventListener('keyup',ku)};
}
function flap(el){
  el.innerHTML='<canvas width="320" height="480" tabindex="0"></canvas><div class="hud">Score <b id="sc">0</b> Best <b id="bs">0</b></div><p class="empty">Tap, click, or press Space to hop through the gaps.</p>';
  const c=el.querySelector('canvas'),x=c.getContext('2d'),W=320,H=480,G=140;
  let y,v,p,f,sc,best=0,over,raf;
  function init(){y=H/2;v=0;p=[];f=0;sc=0;over=false;$('#sc').textContent=0}
  function hop(){if(over)init();else v=-7}
  function tick(){
    if(!over){
      v+=.45;y+=v;f++;
      if(f%90==1)p.push({x:W,t:60+Math.random()*(H-G-120),s:0});
      p.forEach(o=>o.x-=2.4);if(p.length&&p[0].x<-50)p.shift();
      for(const o of p){
        if(!o.s&&o.x+50<68){o.s=1;sc++;$('#sc').textContent=sc;if(sc>best){best=sc;$('#bs').textContent=best}}
        if(92>o.x&&68<o.x+50&&(y-12<o.t||y+12>o.t+G))over=true;
      }
      if(y>H-12||y<-20)over=true;
    }
    draw();raf=requestAnimationFrame(tick);
  }
  function draw(){
    x.fillStyle='#8ecae6';x.fillRect(0,0,W,H);
    x.fillStyle='#14a39a';p.forEach(o=>{x.fillRect(o.x,0,50,o.t);x.fillRect(o.x,o.t+G,50,H)});
    x.fillStyle='#ff6a3d';x.beginPath();x.arc(80,y,12,0,7);x.fill();
    if(over){x.fillStyle='rgba(0,0,0,.55)';x.fillRect(0,0,W,H);x.fillStyle='#fff';x.font='800 28px sans-serif';x.textAlign='center';x.fillText('Game over',W/2,H/2);x.font='15px sans-serif';x.fillText('Tap to try again',W/2,H/2+28)}
  }
  const kd=e=>{if(e.key==' '){e.preventDefault();hop()}};
  document.addEventListener('keydown',kd);c.addEventListener('pointerdown',hop);
  init();tick();
  return()=>{cancelAnimationFrame(raf);document.removeEventListener('keydown',kd)};
}
function merge(el){
  const col={2:'#e9ecfb',4:'#c5b8ff',8:'#ffb199',16:'#ff6a3d',32:'#14a39a',64:'#0e7d76',128:'#7ff0e6',256:'#ffd166',512:'#ef476f',1024:'#6c5ce7',2048:'#1b2250'};
  let g,sc,best=0;
  function add(){const e=[];g.forEach((r,i)=>r.forEach((v,j)=>{if(!v)e.push([i,j])}));if(e.length){const[i,j]=e[Math.random()*e.length|0];g[i][j]=Math.random()<.9?2:4}}
  function init(){g=Array.from({length:4},()=>[0,0,0,0]);sc=0;add();add();draw()}
  function slide(r){const a=r.filter(Boolean);for(let i=0;i<a.length-1;i++)if(a[i]==a[i+1]){a[i]*=2;sc+=a[i];a.splice(i+1,1)}while(a.length<4)a.push(0);return a}
  function move(d){
    const before=JSON.stringify(g);
    for(let k=0;k<4;k++){
      const idx=[0,1,2,3].map(n=>d==0?[k,n]:d==2?[k,3-n]:d==1?[n,k]:[3-n,k]);
      const r=slide(idx.map(([i,j])=>g[i][j]));idx.forEach(([i,j],n)=>g[i][j]=r[n]);
    }
    if(JSON.stringify(g)!=before)add();
    if(sc>best)best=sc;draw();
  }
  const can=()=>g.some((r,i)=>r.some((v,j)=>!v||(j<3&&v==r[j+1])||(i<3&&v==g[i+1][j])));
  function draw(){
    const lost=!can(),won=g.some(r=>r.includes(2048));
    el.innerHTML=`<div class="hud">Score <b>${sc}</b> Best <b>${best}</b></div><div class="board g board-merge">${g.flat().map(v=>`<div class="tilev" style="background:${v?col[v]||'#1b2250':'var(--line)'};color:${v>=32?'#fff':'#1b2250'}">${v||''}</div>`).join('')}</div><div class="hud" aria-live="polite">${lost?'No moves left.':won?'You reached 2048!':'Slide tiles to merge matching numbers.'}</div><div class="pad"><button data-d="U" aria-label="Up">▲</button><button data-d="L" aria-label="Left">◀</button><button data-d="D" aria-label="Down">▼</button><button data-d="R" aria-label="Right">▶</button></div><button id="rs">New game</button>`;
    $('#rs').onclick=init;
  }
  const M={L:0,U:1,R:2,D:3};
  el.onclick=e=>{const b=e.target.closest('[data-d]');if(b)move(M[b.dataset.d])};
  const kd=e=>{const k={ArrowLeft:0,a:0,ArrowUp:1,w:1,ArrowRight:2,d:2,ArrowDown:3,s:3}[e.key];if(k!==undefined){e.preventDefault();move(k)}};
  document.addEventListener('keydown',kd);
  let tx,ty;
  el.addEventListener('touchstart',e=>{tx=e.touches[0].clientX;ty=e.touches[0].clientY},{passive:true});
  el.addEventListener('touchend',e=>{const dx=e.changedTouches[0].clientX-tx,dy=e.changedTouches[0].clientY-ty;if(Math.max(Math.abs(dx),Math.abs(dy))<30)return;move(Math.abs(dx)>Math.abs(dy)?(dx>0?2:0):(dy>0?3:1))});
  init();
  return()=>document.removeEventListener('keydown',kd);
}
function blaster(el){
  el.innerHTML='<canvas width="360" height="480" tabindex="0"></canvas><div class="hud">Score <b id="sc">0</b> Lives <b id="lv">3</b><button id="rs">Restart</button></div><p class="empty">Move with the mouse, your finger, or arrow keys. Your ship fires automatically.</p>';
  const c=el.querySelector('canvas'),x=c.getContext('2d'),W=360,H=480,K={};
  let px,B,E,f,sc,lv,over,raf;
  function init(){px=W/2;B=[];E=[];f=0;sc=0;lv=3;over=false;$('#sc').textContent=0;$('#lv').textContent=3}
  function tick(){
    if(!over){
      f++;if(K.ArrowLeft||K.a)px-=5;if(K.ArrowRight||K.d)px+=5;px=Math.max(16,Math.min(W-16,px));
      if(f%14==0)B.push({x:px,y:H-50});
      if(f%Math.max(18,50-(sc/3|0))==0)E.push({x:20+Math.random()*(W-40),y:-20,vy:1.2+Math.random()+sc/80});
      B.forEach(b=>b.y-=8);E.forEach(e=>e.y+=e.vy);
      for(const e of E)for(const b of B)if(!e.dead&&!b.dead&&Math.abs(e.x-b.x)<16&&Math.abs(e.y-b.y)<16){e.dead=b.dead=1;sc++;$('#sc').textContent=sc}
      E.forEach(e=>{if(!e.dead&&e.y>H-30){e.dead=1;lv--;$('#lv').textContent=lv;if(lv<=0)over=true}});
      B=B.filter(b=>!b.dead&&b.y>-10);E=E.filter(e=>!e.dead);
    }
    draw();raf=requestAnimationFrame(tick);
  }
  function draw(){
    x.fillStyle='#1b2250';x.fillRect(0,0,W,H);
    x.fillStyle='#ffd166';B.forEach(b=>x.fillRect(b.x-2,b.y,4,12));
    x.fillStyle='#ef476f';E.forEach(e=>x.fillRect(e.x-12,e.y-12,24,24));
    x.fillStyle='#7ff0e6';x.beginPath();x.moveTo(px,H-50);x.lineTo(px-16,H-20);x.lineTo(px+16,H-20);x.fill();
    if(over){x.fillStyle='rgba(0,0,0,.6)';x.fillRect(0,0,W,H);x.fillStyle='#fff';x.font='800 28px sans-serif';x.textAlign='center';x.fillText('Game over',W/2,H/2);x.font='15px sans-serif';x.fillText('Press Restart to play again',W/2,H/2+28)}
  }
  const kd=e=>{K[e.key]=1;if(e.key.startsWith('Arrow'))e.preventDefault()},ku=e=>{K[e.key]=0};
  document.addEventListener('keydown',kd);document.addEventListener('keyup',ku);
  c.addEventListener('pointermove',e=>{const r=c.getBoundingClientRect();px=Math.max(16,Math.min(W-16,(e.clientX-r.left)*W/r.width))});
  $('#rs').onclick=init;init();tick();
  return()=>{cancelAnimationFrame(raf);document.removeEventListener('keydown',kd);document.removeEventListener('keyup',ku)};
}
function sweeper(el){
  const N=9,M=10;let g,placed,over,won,flagMode;
  const nb=i=>{const r=i/N|0,c=i%N,o=[];for(let a=-1;a<=1;a++)for(let b=-1;b<=1;b++)if((a||b)&&r+a>=0&&r+a<N&&c+b>=0&&c+b<N)o.push((r+a)*N+c+b);return o};
  function init(){g=Array.from({length:N*N},()=>({m:0,o:0,f:0,n:0}));placed=false;over=won=false;flagMode=false;draw()}
  function place(s){let k=0;while(k<M){const i=Math.random()*N*N|0;if(i!=s&&!g[i].m){g[i].m=1;k++}}g.forEach((c,i)=>c.n=nb(i).filter(j=>g[j].m).length)}
  function open(i){const c=g[i];if(c.o||c.f)return;c.o=1;if(c.m){over=true;return}if(!c.n)nb(i).forEach(open)}
  function act(i,flag){
    if(over||won)return;const c=g[i];
    if(flag){if(!c.o)c.f^=1}
    else{if(c.f||c.o)return;if(!placed){place(i);placed=true}open(i);if(!over&&g.every(q=>q.m||q.o))won=true}
    draw();
  }
  function draw(){
    const fl=g.filter(c=>c.f).length;
    el.innerHTML=`<div class="hud" aria-live="polite">Mines left ${M-fl}${won?' · You cleared the field!':over?' · Boom. Try again.':''}</div><div class="board s">${g.map((c,i)=>{const show=c.o||(over&&c.m);const t=show?(c.m?'💣':c.n||''):c.f?'🚩':'';return`<button class="cell" data-i="${i}" aria-label="Square ${i+1}" style="${show?'background:var(--line);border-color:transparent':''}">${t}</button>`}).join('')}</div><div class="hud"><button id="md">${flagMode?'Mode: place flags':'Mode: dig'}</button><button id="rs">New game</button></div>`;
    $('#md').onclick=()=>{flagMode=!flagMode;draw()};$('#rs').onclick=init;
  }
  el.onclick=e=>{const b=e.target.closest('[data-i]');if(b)act(+b.dataset.i,flagMode)};
  el.oncontextmenu=e=>{const b=e.target.closest('[data-i]');if(b){e.preventDefault();act(+b.dataset.i,true)}};
  init();return()=>{el.onclick=el.oncontextmenu=null};
}
function paddle(el){
  el.innerHTML='<canvas width="320" height="440" tabindex="0"></canvas><div class="hud">You <b id="ps">0</b> Computer <b id="as">0</b><button id="rs">Restart</button></div><p class="empty">Move the mouse, your finger, or use the arrow keys. First to 7 wins.</p>';
  const c=el.querySelector('canvas'),x=c.getContext('2d'),W=320,H=440,PW=64,K={};
  let px,ax,bx,by,vx,vy,ps,as,over,raf;
  const cl=v=>Math.max(PW/2,Math.min(W-PW/2,v)),upd=()=>{$('#ps').textContent=ps;$('#as').textContent=as};
  function serve(d){bx=W/2;by=H/2;vx=(Math.random()<.5?-1:1)*2.5;vy=3.5*d}
  function init(){px=ax=W/2;ps=as=0;over=false;serve(1);upd()}
  function tick(){
    if(!over){
      if(K.ArrowLeft||K.a)px-=6;if(K.ArrowRight||K.d)px+=6;px=cl(px);
      ax=cl(ax+Math.max(-3.4,Math.min(3.4,bx-ax)));
      bx+=vx;by+=vy;if(bx<6||bx>W-6)vx=-vx;
      if(vy>0&&by>H-28&&by<H-14&&Math.abs(bx-px)<PW/2+6){vy=-Math.min(7,vy*1.06);vx=(bx-px)/(PW/2)*4}
      if(vy<0&&by<28&&by>14&&Math.abs(bx-ax)<PW/2+6){vy=Math.min(7,-vy*1.06);vx=(bx-ax)/(PW/2)*3}
      if(by<0){ps++;upd();serve(1)}
      if(by>H){as++;upd();serve(-1)}
      if(ps>=7||as>=7)over=true;
    }
    draw();raf=requestAnimationFrame(tick);
  }
  function draw(){
    x.fillStyle='#1b2250';x.fillRect(0,0,W,H);x.fillStyle='#fff';
    x.fillRect(px-PW/2,H-24,PW,10);x.fillRect(ax-PW/2,14,PW,10);x.beginPath();x.arc(bx,by,6,0,7);x.fill();
    if(over){x.fillStyle='rgba(0,0,0,.6)';x.fillRect(0,0,W,H);x.fillStyle='#fff';x.font='800 28px sans-serif';x.textAlign='center';x.fillText(ps>=7?'You win!':'Computer wins',W/2,H/2);x.font='15px sans-serif';x.fillText('Press Restart to play again',W/2,H/2+28)}
  }
  const kd=e=>{K[e.key]=1;if(e.key.startsWith('Arrow'))e.preventDefault()},ku=e=>{K[e.key]=0};
  document.addEventListener('keydown',kd);document.addEventListener('keyup',ku);
  c.addEventListener('pointermove',e=>{const r=c.getBoundingClientRect();px=cl((e.clientX-r.left)*W/r.width)});
  $('#rs').onclick=init;init();tick();
  return()=>{cancelAnimationFrame(raf);document.removeEventListener('keydown',kd);document.removeEventListener('keyup',ku)};
}
function four(el){
  const R=6,C=7;let g,over,msg;
  function init(){g=Array.from({length:R},()=>Array(C).fill(0));over=false;msg='Your turn: pick a column to drop a disc.';draw()}
  const drop=(c,p)=>{for(let r=R-1;r>=0;r--)if(!g[r][c]){g[r][c]=p;return r}return -1};
  function win(p){for(let r=0;r<R;r++)for(let c=0;c<C;c++)for(const[dr,dc]of[[0,1],[1,0],[1,1],[1,-1]]){let k=0;for(;k<4;k++){const a=r+dr*k,b=c+dc*k;if(a<0||a>=R||b<0||b>=C||g[a][b]!=p)break}if(k==4)return true}return false}
  const full=()=>g[0].every(Boolean);
  function ai(){
    const cols=[...Array(C).keys()].filter(c=>!g[0][c]);
    for(const p of[2,1])for(const c of cols){const r=drop(c,p),w=win(p);g[r][c]=0;if(w){drop(c,2);return}}
    cols.sort((a,b)=>Math.abs(a-3)-Math.abs(b-3));drop(cols[Math.random()<.7?0:(Math.random()*cols.length|0)],2);
  }
  function draw(){
    el.innerHTML=`<div class="hud" aria-live="polite">${msg}</div><div class="board c4">${g.flatMap(row=>row.map((v,c)=>`<button class="cell" data-c="${c}" aria-label="Column ${c+1}" style="background:${v==1?'#ff6a3d':v==2?'#ffd166':'var(--card)'}"></button>`)).join('')}</div><button id="rs">New game</button>`;
    $('#rs').onclick=init;
  }
  el.onclick=e=>{
    const b=e.target.closest('[data-c]');if(!b||over)return;
    if(drop(+b.dataset.c,1)<0)return;
    if(win(1)){over=true;msg='You win!'}
    else if(full()){over=true;msg='It\u2019s a draw.'}
    else{ai();if(win(2)){over=true;msg='Computer wins.'}else if(full()){over=true;msg='It\u2019s a draw.'}else msg='Your turn.'}
    draw();
  };
  init();return()=>{el.onclick=null};
}
function mole(el){
  let sc,t,cur,iv,tm,run;
  function end(){run=false;clearInterval(iv);clearInterval(tm);cur=-1;draw()}
  function start(){clearInterval(iv);clearInterval(tm);sc=0;t=30;cur=-1;run=true;draw();
    iv=setInterval(()=>{t--;if(t<=0)end();else draw()},1000);
    tm=setInterval(()=>{cur=Math.random()*9|0;draw()},750)}
  function draw(){
    el.innerHTML=`<div class="hud" aria-live="polite">Score <b>${sc}</b> Time <b>${t}</b>s${!run&&t===0?' · Time\u2019s up!':''}</div><div class="board t">${Array.from({length:9},(_,i)=>`<button class="cell" data-i="${i}" aria-label="Hole ${i+1}">${i==cur?'🐹':''}</button>`).join('')}</div><button id="rs">${run?'Restart':'Start'}</button>`;
    $('#rs').onclick=start;
  }
  el.onclick=e=>{const b=e.target.closest('[data-i]');if(b&&run&&+b.dataset.i==cur){sc++;cur=-1;draw()}};
  sc=0;t=30;cur=-1;run=false;draw();
  return()=>{clearInterval(iv);clearInterval(tm);el.onclick=null};
}
function echo(el){
  const cs=['#ff6a3d','#14a39a','#ffd166','#6c5ce7'];
  let seq,pos=0,busy=false,msg='Press Start to begin.',on=-1,tm=[];
  const later=(f,ms)=>tm.push(setTimeout(f,ms));
  function draw(){
    el.innerHTML=`<div class="hud" aria-live="polite">${msg}</div><div class="board" style="grid-template-columns:repeat(2,110px)">${cs.map((c,i)=>`<button class="cell" data-i="${i}" aria-label="Color ${i+1}" style="height:110px;background:${c};border-color:${c};opacity:${on==i?1:.45}"></button>`).join('')}</div><button id="rs">Start new game</button>`;
    $('#rs').onclick=start;
  }
  function play(){
    busy=true;pos=0;msg='Watch the pattern…';draw();
    seq.forEach((v,k)=>{later(()=>{on=v;draw()},600+k*700);later(()=>{on=-1;draw()},600+k*700+450)});
    later(()=>{busy=false;msg='Your turn: repeat it.';draw()},600+seq.length*700);
  }
  function start(){tm.forEach(clearTimeout);tm=[];on=-1;seq=[Math.random()*4|0];play()}
  el.onclick=e=>{
    const b=e.target.closest('.cell');if(!b||busy||!seq)return;const i=+b.dataset.i;
    if(i!=seq[pos]){msg=`Wrong one. You reached round ${seq.length}.`;seq=null;on=-1;draw();return}
    pos++;on=i;later(()=>{on=-1;draw()},200);
    if(pos==seq.length){seq.push(Math.random()*4|0);busy=true;msg='Nice! Next round…';draw();later(play,900)}else draw();
  };
  draw();return()=>{tm.forEach(clearTimeout);el.onclick=null};
}
function hangman(el){
  const W=['rocket','garden','puzzle','jungle','planet','guitar','pencil','bridge','castle','dragon','market','island','winter','coffee','silver','pirate','window','cactus','anchor','magnet'];
  let w,gs;
  function init(){w=W[Math.random()*W.length|0];gs=new Set();draw()}
  function draw(){
    const wrong=[...gs].filter(l=>!w.includes(l)).length,won=[...w].every(l=>gs.has(l)),lost=wrong>=6;
    el.innerHTML=`<div class="hud" style="font:800 34px 'Bricolage Grotesque',sans-serif;letter-spacing:.2em">${[...w].map(l=>gs.has(l)||lost?l:'_').join(' ')}</div><div class="hud" aria-live="polite">Misses ${wrong} of 6${won?' · You got it!':lost?' · Out of guesses.':''}</div><div class="keys">${'abcdefghijklmnopqrstuvwxyz'.split('').map(l=>`<button data-l="${l}" ${gs.has(l)||won||lost?'disabled':''}>${l}</button>`).join('')}</div><button id="rs">New word</button>`;
    $('#rs').onclick=init;
  }
  el.onclick=e=>{const b=e.target.closest('[data-l]');if(b){gs.add(b.dataset.l);draw()}};
  init();return()=>{el.onclick=null};
}
function lights(el){
  let g,mv;
  const tog=i=>{const r=i/5|0,c=i%5;[[0,0],[1,0],[-1,0],[0,1],[0,-1]].forEach(([a,b])=>{const rr=r+a,cc=c+b;if(rr>=0&&rr<5&&cc>=0&&cc<5)g[rr*5+cc]^=1})};
  function init(){g=Array(25).fill(0);mv=0;for(let k=0;k<12;k++)tog(Math.random()*25|0);if(!g.some(Boolean))tog(12);draw()}
  function draw(){
    const won=!g.some(Boolean);
    el.innerHTML=`<div class="hud" aria-live="polite">Moves <b>${mv}</b>${won?' · All lights are off. You win!':' · Turn every light off.'}</div><div class="board l">${g.map((v,i)=>`<button class="cell" data-i="${i}" aria-label="Light ${i+1} ${v?'on':'off'}" style="background:${v?'#ffd166':'var(--ink)'};border-color:${v?'#ffd166':'var(--ink)'}"></button>`).join('')}</div><button id="rs">New puzzle</button>`;
    $('#rs').onclick=init;
  }
  el.onclick=e=>{const b=e.target.closest('[data-i]');if(!b||!g.some(Boolean))return;tog(+b.dataset.i);mv++;draw()};
  init();return()=>{el.onclick=null};
}
function slidep(el){
  const N=3;let g,mv;
  const nbr=i=>{const r=i/N|0,c=i%N,o=[];if(r>0)o.push(i-N);if(r<N-1)o.push(i+N);if(c>0)o.push(i-1);if(c<N-1)o.push(i+1);return o};
  function init(){
    g=[1,2,3,4,5,6,7,8,0];mv=0;let e=8,prev=-1;
    for(let k=0;k<120;k++){const o=nbr(e).filter(j=>j!=prev),j=o[Math.random()*o.length|0];g[e]=g[j];g[j]=0;prev=e;e=j}
    draw();
  }
  const solved=()=>g.every((v,i)=>v==(i+1)%9);
  function draw(){
    el.innerHTML=`<div class="hud" aria-live="polite">Moves <b>${mv}</b>${solved()?' · Solved!':' · Put the numbers in order.'}</div><div class="board p">${g.map((v,i)=>`<button class="cell" data-i="${i}" ${v?'':'disabled'} aria-label="${v?'Tile '+v:'Empty'}" style="${v?'':'visibility:hidden'}">${v||''}</button>`).join('')}</div><button id="rs">Shuffle</button>`;
    $('#rs').onclick=init;
  }
  el.onclick=e=>{const b=e.target.closest('[data-i]');if(!b||solved())return;const i=+b.dataset.i,z=g.indexOf(0);if(nbr(z).includes(i)){g[z]=g[i];g[i]=0;mv++;draw()}};
  init();return()=>{el.onclick=null};
}
function dodge(el){
  el.innerHTML='<canvas width="360" height="420" tabindex="0"></canvas><div class="hud">Time <b id="sc">0</b>s Best <b id="bs">0</b>s<button id="rs">Restart</button></div><p class="empty">Move with the mouse, your finger, or arrow keys. Avoid the falling blocks.</p>';
  const c=el.querySelector('canvas'),x=c.getContext('2d'),W=360,H=420,K={};
  let px,bl,f,over,best=0,raf;
  function init(){px=W/2;bl=[];f=0;over=false;$('#sc').textContent=0}
  function tick(){
    if(!over){
      f++;if(K.ArrowLeft||K.a)px-=6;if(K.ArrowRight||K.d)px+=6;px=Math.max(10,Math.min(W-10,px));
      if(f%Math.max(10,30-(f/200|0))==0){const w=20+Math.random()*40;bl.push({x:Math.random()*(W-w),y:-20,w,h:18,v:2+Math.random()*2+f/600})}
      bl.forEach(b=>b.y+=b.v);bl=bl.filter(b=>b.y<H+30);
      for(const b of bl)if(px+10>b.x&&px-10<b.x+b.w&&H-20>b.y&&H-40<b.y+b.h)over=true;
      const s=f/60|0;$('#sc').textContent=s;if(over&&s>best){best=s;$('#bs').textContent=best}
    }
    draw();raf=requestAnimationFrame(tick);
  }
  function draw(){
    x.fillStyle='#1b2250';x.fillRect(0,0,W,H);
    x.fillStyle='#ff6a3d';bl.forEach(b=>x.fillRect(b.x,b.y,b.w,b.h));
    x.fillStyle='#7ff0e6';x.beginPath();x.arc(px,H-30,10,0,7);x.fill();
    if(over){x.fillStyle='rgba(0,0,0,.6)';x.fillRect(0,0,W,H);x.fillStyle='#fff';x.font='800 28px sans-serif';x.textAlign='center';x.fillText('Game over',W/2,H/2);x.font='15px sans-serif';x.fillText('Press Restart to play again',W/2,H/2+28)}
  }
  const kd=e=>{K[e.key]=1;if(e.key.startsWith('Arrow'))e.preventDefault()},ku=e=>{K[e.key]=0};
  document.addEventListener('keydown',kd);document.addEventListener('keyup',ku);
  c.addEventListener('pointermove',e=>{const r=c.getBoundingClientRect();px=Math.max(10,Math.min(W-10,(e.clientX-r.left)*W/r.width))});
  $('#rs').onclick=init;init();tick();
  return()=>{cancelAnimationFrame(raf);document.removeEventListener('keydown',kd);document.removeEventListener('keyup',ku)};
}
const HELP={
  lane:'Move with the mouse, your finger, or the arrow keys. Your ship fires on its own. Grab » for stronger shots and + for health.',
  arena:'Move with the mouse, your finger, or the arrow keys. Your ship aims and fires at the nearest enemy on its own.',
  turret:'Aim with the mouse, your finger, or the arrow keys. The turret fires on its own. Don\u2019t let anything reach it.',
  invader:'Slide left and right with the mouse, your finger, or the arrow keys. Clear each wave before it lands.'
};
const SHOOTERS={
 'neon-strike':{mode:'lane',shape:'diamond',bg:['#0a0020','#2b0a5e'],deco:'grid',gc:'#ff2bd6',pc:'#7ff0e6',bc:'#ffe066',ec:['#ff2bd6','#ff7a3d','#8f6bff'],eshoot:1,rate:11},
 'void-raider':{mode:'lane',side:1,w:640,h:420,shape:'hex',bg:['#02060f','#0b2a4a'],deco:'nebula',gc:'#2a6bff',gc2:'#00d4ff',pc:'#ffffff',bc:'#9be7ff',ec:['#4cc9f0','#4895ef','#d65db1'],eshoot:1,rate:10,sp:44},
 'crimson-skies':{mode:'lane',shape:'tri',bg:['#1a0505','#5c1010'],deco:'nebula',gc:'#ff3b30',gc2:'#ff9500',pc:'#ffd166',bc:'#fff3b0',ec:['#ffb703','#fb8500','#ff6b6b'],eshoot:1,hp:4,er:19,ehp:2,es:1.2,sp:60,rate:10},
 'deep-current':{mode:'lane',side:1,w:640,h:420,shape:'circle',bg:['#00121f','#003a5c'],deco:'nebula',gc:'#00b4d8',gc2:'#48cae4',pc:'#ffd166',bc:'#ffffff',ec:['#90e0ef','#ffafcc','#bde0fe'],rate:9,sp:30,es:2},
 'cyber-arena':{mode:'arena',w:560,h:560,shape:'hex',bg:['#06060f','#0f1630'],deco:'grid',gc:'#00f5d4',pc:'#00f5d4',bc:'#fee440',ec:['#f15bb5','#fee440','#9b5de5'],rate:9,es:1.2,sp:42},
 'ghost-hunt':{mode:'arena',w:560,h:560,shape:'circle',bg:['#0b1a12','#14301f'],deco:'nebula',gc:'#2dd36f',gc2:'#9cff57',pc:'#ffd166',bc:'#9cff57',ec:['#d0f4de','#a9def9','#e4c1f9'],rate:10,es:1,sp:36,ehp:2,er:17},
 'last-bastion':{mode:'turret',shape:'tri',bg:['#1b1030','#3b1f4f'],deco:'nebula',gc:'#ff7bd0',gc2:'#7b2cbf',pc:'#7ff0e6',bc:'#ffffff',ec:['#ff9e00','#ff5d8f','#ffd166'],rate:8,es:1,sp:50,ehp:2,er:17},
 'rooftop-defense':{mode:'turret',shape:'star',bg:['#0a1428','#17335f'],deco:'grid',gc:'#4cc9f0',pc:'#ffffff',bc:'#ffd166',ec:['#ffd166','#ef476f','#06d6a0'],rate:7,es:1.2,sp:40,er:16},
 'alien-wave':{mode:'invader',shape:'star',bg:['#050a05','#0d2a12'],deco:'grid',gc:'#39ff14',pc:'#39ff14',bc:'#ffffff',ec:['#39ff14','#c6ff00','#00e676'],rate:16,ebc:'#ff4d6d'},
 'galaxy-guard':{mode:'invader',shape:'diamond',bg:['#10002b','#240046'],deco:'nebula',gc:'#9d4edd',gc2:'#ff6ec7',pc:'#ffffff',bc:'#ff6ec7',ec:['#ff6ec7','#ffd166','#7ff0e6'],rate:14,ebc:'#ffd166'}
};
function shoot(el,C){
  const W=C.w||480,H=C.h||640,M=C.mode,side=!!C.side,TAU=Math.PI*2,R=Math.random;
  el.innerHTML=`<canvas width="${W}" height="${H}" tabindex="0"></canvas><div class="hud">Score <b id="sc">0</b> Health <b id="hp">0</b> Best <b id="bs">0</b><button id="rs">Restart</button></div><p class="empty">${C.help||HELP[M]}</p>`;
  const c=el.querySelector('canvas'),x=c.getContext('2d'),K={},F=side?[1,0]:[0,-1],N={diamond:4,tri:3,hex:6,square:4};
  let S,best=0,raf,mx,my;
  function init(){
    S={f:0,sc:0,hp:C.hp||3,w:1,Bu:[],En:[],Eb:[],Pa:[],Pw:[],sh:0,inv:0,over:false,wave:1,dir:1,aim:-Math.PI/2,
      p:{x:M=='turret'?W/2:side?W*.12:W/2,y:M=='turret'?H-34:M=='invader'?H-40:side?H/2:M=='arena'?H/2:H*.82},
      st:Array.from({length:90},()=>({x:R()*W,y:R()*H,z:.3+R()*1.3}))};
    mx=S.p.x;my=M=='turret'?H*.3:S.p.y;
    if(M=='invader')spawnWave();
    $('#bs').textContent=best;
  }
  function spawnWave(){S.En=[];S.dir=1;for(let r=0;r<4;r++)for(let k=0;k<7;k++)S.En.push({x:60+k*(W-120)/6,y:70+r*44,r:15,hp:1,t:r%C.ec.length,cd:60+R()*300,ph:R()*TAU})}
  function boom(px,py,col,n){for(let i=0;i<n;i++){const a=R()*TAU,s=1+R()*4;S.Pa.push({x:px,y:py,vx:Math.cos(a)*s,vy:Math.sin(a)*s,l:30,c:col})}}
  function hurt(){const p=S.p;if(S.inv>0||S.over)return;S.hp--;S.inv=90;S.sh=14;boom(p.x,p.y,C.pc,26);if(S.hp<=0){S.over=true;if(S.sc>best)best=S.sc;$('#bs').textContent=best}}
  function spawn(){
    const e={r:C.er||15,hp:C.ehp||1,t:R()*C.ec.length|0,ph:R()*TAU,cd:60+R()*120,v:(C.es||1.6)+S.sc/220};
    if(M=='lane'){e.x=side?W+20:20+R()*(W-40);e.y=side?20+R()*(H-40):-20}
    else if(M=='arena'){const s=R()*4|0;e.x=s==0?-20:s==1?W+20:R()*W;e.y=s==2?-20:s==3?H+20:R()*H}
    else{e.x=20+R()*(W-40);e.y=-20}
    S.En.push(e);
  }
  function update(){
    const p=S.p;S.f++;
    if(K.ArrowLeft||K.a)mx-=7;if(K.ArrowRight||K.d)mx+=7;if(K.ArrowUp||K.w)my-=7;if(K.ArrowDown||K.s)my+=7;
    mx=Math.max(0,Math.min(W,mx));my=Math.max(0,Math.min(H,my));
    if(M=='lane'){if(side){p.x+=(Math.min(mx,W*.45)-p.x)*.2;p.y+=(my-p.y)*.2}else{p.x+=(mx-p.x)*.2;p.y+=(Math.max(my,H*.55)-p.y)*.2}}
    else if(M=='arena'){const dx=mx-p.x,dy=my-p.y,d=Math.hypot(dx,dy);if(d>3){const v=Math.min(d*.15,4.2);p.x+=dx/d*v;p.y+=dy/d*v}}
    else if(M=='invader')p.x+=(mx-p.x)*.25;
    p.x=Math.max(16,Math.min(W-16,p.x));p.y=Math.max(16,Math.min(H-16,p.y));
    if(M=='turret')S.aim=Math.atan2(my-p.y,mx-p.x);
    else if(M=='arena'){let d=1e9,t;S.En.forEach(e=>{const q=(e.x-p.x)**2+(e.y-p.y)**2;if(q<d){d=q;t=e}});if(t)S.aim=Math.atan2(t.y-p.y,t.x-p.x)}
    else S.aim=Math.atan2(F[1],F[0]);
    if(S.f%(C.rate||12)==0&&(M!='arena'||S.En.length)){const o=S.w==1?[0]:S.w==2?[-.09,.09]:[-.2,0,.2];o.forEach(q=>S.Bu.push({x:p.x,y:p.y,vx:Math.cos(S.aim+q)*9,vy:Math.sin(S.aim+q)*9}))}
    if(M=='invader'){
      const v=Math.min(4,.5+S.wave*.15+(1-S.En.length/28)*1.2);let edge=false;
      S.En.forEach(e=>{e.x+=S.dir*v;if(e.x<24||e.x>W-24)edge=true});
      if(edge){S.dir*=-1;S.En.forEach(e=>e.y+=16)}
      S.En.forEach(e=>{if(--e.cd<=0){e.cd=140+R()*260/Math.sqrt(S.wave);S.Eb.push({x:e.x,y:e.y+10,vx:0,vy:4})}});
      if(S.En.some(e=>e.y>H-70)){S.inv=0;S.hp=1;hurt()}
      if(!S.En.length){S.wave++;S.sc+=50;spawnWave()}
    }else{
      if(S.f%Math.max(C.min||12,Math.round((C.sp||50)-S.sc/6))==0)spawn();
      S.En.forEach(e=>{
        if(M=='lane'){
          const wig=Math.sin(S.f*.05+e.ph)*1.2;e.x-=F[0]*e.v;e.y-=F[1]*e.v;if(side)e.y+=wig;else e.x+=wig;
          if(C.eshoot&&--e.cd<=0){e.cd=90+R()*150;S.Eb.push({x:e.x,y:e.y,vx:-F[0]*4,vy:-F[1]*4})}
        }else{const tx=M=='turret'?W/2:p.x,ty=M=='turret'?H-34:p.y,dx=tx-e.x,dy=ty-e.y,d=Math.hypot(dx,dy)||1;e.x+=dx/d*e.v;e.y+=dy/d*e.v}
      });
    }
    S.Bu.forEach(b=>{b.x+=b.vx;b.y+=b.vy});S.Eb.forEach(b=>{b.x+=b.vx;b.y+=b.vy});
    for(const e of S.En)for(const b of S.Bu)if(!e.dead&&!b.dead&&(e.x-b.x)**2+(e.y-b.y)**2<(e.r+4)**2){
      b.dead=1;e.hp--;boom(b.x,b.y,C.ec[e.t],3);
      if(e.hp<=0){e.dead=1;S.sc+=10;boom(e.x,e.y,C.ec[e.t],22);S.sh=Math.max(S.sh,5);if(R()<.1)S.Pw.push({x:e.x,y:e.y,k:R()<.55?'w':'h'})}
    }
    if(M!='invader')S.En.forEach(e=>{if(!e.dead&&(e.x-p.x)**2+(e.y-p.y)**2<(e.r+(M=='turret'?16:11))**2){e.dead=1;boom(e.x,e.y,C.ec[e.t],16);hurt()}});
    S.Eb.forEach(b=>{if((b.x-p.x)**2+(b.y-p.y)**2<144){b.dead=1;hurt()}});
    S.Pw.forEach(q=>{if(M=='lane'){q.x-=F[0]*1.2;q.y-=F[1]*1.2}else q.y+=1.2;
      if((q.x-p.x)**2+(q.y-p.y)**2<576){q.dead=1;if(q.k=='w')S.w=Math.min(3,S.w+1);else S.hp=Math.min(5,S.hp+1);boom(q.x,q.y,'#8ef08e',14)}});
    const inb=b=>b.x>-30&&b.x<W+30&&b.y>-30&&b.y<H+30&&!b.dead;
    S.Bu=S.Bu.filter(inb);S.Eb=S.Eb.filter(inb);S.Pw=S.Pw.filter(inb);
    S.En=S.En.filter(e=>!e.dead&&(M!='lane'||(side?e.x>-40:e.y<H+40)));
    S.inv--;$('#sc').textContent=S.sc;$('#hp').textContent=Math.max(0,S.hp);
  }
  function fx(){
    S.sh*=.85;S.Pa.forEach(q=>{q.x+=q.vx;q.y+=q.vy;q.vx*=.96;q.vy*=.96;q.l--});S.Pa=S.Pa.filter(q=>q.l>0);
    S.st.forEach(s=>{s.x+=M=='lane'?-F[0]*2.2*s.z:0;s.y+=M=='lane'?-F[1]*2.2*s.z:.3*s.z;if(s.x<0)s.x+=W;if(s.x>W)s.x-=W;if(s.y<0)s.y+=H;if(s.y>H)s.y-=H});
  }
  function poly(n,r,rot){x.beginPath();for(let i=0;i<n;i++){const a=rot+i*TAU/n;x[i?'lineTo':'moveTo'](Math.cos(a)*r,Math.sin(a)*r)}x.closePath()}
  function draw(){
    const p=S.p;x.save();
    const g=x.createLinearGradient(0,0,0,H);g.addColorStop(0,C.bg[0]);g.addColorStop(1,C.bg[1]);x.fillStyle=g;x.fillRect(0,0,W,H);
    if(C.deco=='grid'){x.strokeStyle=C.gc;x.lineWidth=1;x.globalAlpha=.22;const o=(S.f*.6)%40;x.beginPath();for(let i=-1;i<=H/40;i++){x.moveTo(0,i*40+o);x.lineTo(W,i*40+o)}for(let i=0;i<=W/40;i++){x.moveTo(i*40,0);x.lineTo(i*40,H)}x.stroke();x.globalAlpha=1}
    if(C.deco=='nebula')[[.25,.3,C.gc],[.8,.7,C.gc2||C.gc]].forEach(([a,b,col])=>{const r=x.createRadialGradient(W*a,H*b,0,W*a,H*b,W*.6);r.addColorStop(0,col);r.addColorStop(1,'rgba(0,0,0,0)');x.globalAlpha=.35;x.fillStyle=r;x.fillRect(0,0,W,H);x.globalAlpha=1});
    x.fillStyle='#fff';S.st.forEach(s=>{x.globalAlpha=.3+.5*s.z/1.6;x.fillRect(s.x,s.y,s.z*1.6,s.z*1.6)});x.globalAlpha=1;
    x.translate((R()-.5)*S.sh,(R()-.5)*S.sh);
    S.En.forEach(e=>{
      const col=C.ec[e.t],rot=S.f*.02+e.ph;x.save();x.translate(e.x,e.y);x.shadowBlur=16;x.shadowColor=col;x.fillStyle=col;
      if(C.shape=='circle'){x.beginPath();x.arc(0,0,e.r,0,TAU)}
      else if(C.shape=='star'){x.beginPath();for(let i=0;i<10;i++){const a=rot+i*Math.PI/5,r=i%2?e.r*.5:e.r;x[i?'lineTo':'moveTo'](Math.cos(a)*r,Math.sin(a)*r)}x.closePath()}
      else poly(N[C.shape]||4,e.r,C.shape=='tri'?(M=='lane'?Math.atan2(-F[1],-F[0]):Math.PI/2):C.shape=='square'?Math.PI/4:rot);
      x.fill();x.shadowBlur=0;x.fillStyle='rgba(255,255,255,.55)';x.beginPath();x.arc(0,0,e.r*.28,0,TAU);x.fill();x.restore();
    });
    x.lineCap='round';x.lineWidth=3;x.shadowBlur=12;x.shadowColor=x.strokeStyle=C.bc;
    S.Bu.forEach(b=>{x.beginPath();x.moveTo(b.x,b.y);x.lineTo(b.x-b.vx*1.2,b.y-b.vy*1.2);x.stroke()});
    x.shadowColor=x.fillStyle=C.ebc||'#ff4d6d';S.Eb.forEach(b=>{x.beginPath();x.arc(b.x,b.y,4,0,TAU);x.fill()});
    x.shadowBlur=0;x.lineWidth=2;x.font='800 14px sans-serif';x.textAlign='center';
    S.Pw.forEach(q=>{const col=q.k=='w'?'#7ff0e6':'#8ef08e';x.strokeStyle=x.fillStyle=col;x.beginPath();x.arc(q.x,q.y,11,0,TAU);x.stroke();x.fillText(q.k=='w'?'»':'+',q.x,q.y+5)});
    if(!S.over&&!(S.inv>0&&S.f%8<4)){
      x.save();x.translate(p.x,p.y);x.rotate(S.aim+Math.PI/2);x.shadowBlur=18;x.shadowColor=C.pc;x.fillStyle=C.pc;
      if(M=='turret'){x.beginPath();x.arc(0,0,16,0,TAU);x.fill();x.fillRect(-4,-30,8,24)}
      else{x.beginPath();x.moveTo(0,-18);x.lineTo(13,14);x.lineTo(0,8);x.lineTo(-13,14);x.closePath();x.fill();
        if(M!='arena'){x.fillStyle=C.bc;x.beginPath();x.moveTo(-5,10);x.lineTo(5,10);x.lineTo(0,17+R()*10);x.fill()}}
      x.restore();
    }
    x.globalCompositeOperation='lighter';S.Pa.forEach(q=>{x.globalAlpha=q.l/30;x.fillStyle=q.c;x.fillRect(q.x,q.y,3,3)});x.globalCompositeOperation='source-over';x.globalAlpha=1;
    x.restore();
    const v=x.createRadialGradient(W/2,H/2,Math.min(W,H)*.35,W/2,H/2,Math.max(W,H)*.75);v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,'rgba(0,0,0,.5)');x.fillStyle=v;x.fillRect(0,0,W,H);
    if(S.over){x.fillStyle='rgba(0,0,0,.6)';x.fillRect(0,0,W,H);x.fillStyle='#fff';x.font='800 30px sans-serif';x.textAlign='center';x.fillText('Game over',W/2,H/2-6);x.font='16px sans-serif';x.fillText('Score '+S.sc+'. Press Restart to play again.',W/2,H/2+24)}
  }
  function tick(){if(!S.over)update();fx();draw();raf=requestAnimationFrame(tick)}
  const kd=e=>{K[e.key]=1;if(e.key.startsWith('Arrow'))e.preventDefault()},ku=e=>{K[e.key]=0};
  const mv=e=>{const r=c.getBoundingClientRect();mx=(e.clientX-r.left)*W/r.width;my=(e.clientY-r.top)*H/r.height};
  document.addEventListener('keydown',kd);document.addEventListener('keyup',ku);
  c.addEventListener('pointermove',mv);c.addEventListener('pointerdown',mv);
  $('#rs').onclick=init;init();tick();
  return()=>{cancelAnimationFrame(raf);document.removeEventListener('keydown',kd);document.removeEventListener('keyup',ku)};
}
const ROYALE={
 'island-royale':{world:3000,bots:14,houses:9,trees:130,rocks:30,loot:44,mats:150,acc:.32,
  th:{water:'#1d6fa5',sand:'#e8d9a0',g1:'#86c872',g2:'#74b862',tree:'#2f7d3a',rock:'#8a8f98',wall:'#b98a52',floor:'#d6b88a',storm:'rgba(150,60,230,.38)'},
  ph:[{w:1500,s:1200,f:.62},{w:1200,s:1000,f:.38},{w:900,s:800,f:.2},{w:600,s:600,f:.08},{w:300,s:500,f:.02}]},
 'frost-royale':{world:3400,bots:19,houses:10,trees:150,rocks:40,loot:52,mats:150,acc:.3,
  th:{water:'#6fa8c9',sand:'#f2f7fa',g1:'#e3eef5',g2:'#d3e3ee',tree:'#2b6b55',rock:'#7d8a96',wall:'#8fb4cf',floor:'#bcd0de',storm:'rgba(80,140,255,.38)'},
  ph:[{w:1500,s:1300,f:.62},{w:1200,s:1100,f:.38},{w:900,s:900,f:.2},{w:600,s:700,f:.08},{w:300,s:500,f:.02}]},
 'desert-rush':{world:2200,bots:8,houses:6,trees:60,rocks:45,loot:34,mats:120,acc:.28,sd:3,
  th:{water:'#2a8ea6',sand:'#f6dba0',g1:'#e8bd76',g2:'#dcae63',tree:'#5d8a3a',rock:'#9c7b5a',wall:'#a67856',floor:'#caa06b',storm:'rgba(255,120,40,.35)'},
  ph:[{w:900,s:800,f:.6},{w:700,s:700,f:.35},{w:500,s:600,f:.15},{w:300,s:500,f:.02}]},
 'build-fight':{world:1500,bots:3,houses:2,trees:12,rocks:10,loot:16,mats:300,inf:1,acc:.3,
  th:{water:'#274c77',sand:'#cfd8e3',g1:'#8bd17c',g2:'#7cc56d',tree:'#2f7d3a',rock:'#8a8f98',wall:'#c08a4f',floor:'#d9c3a0',storm:'rgba(150,60,230,.38)'},ph:[]}
};
function royale(el,C){
  const W=720,H=460,T=48,TAU=Math.PI*2,R=Math.random,WS=C.world,WC=WS/2,IR=WS*.47,MW=Math.ceil(WS/T),th=C.th,K={};
  const GUNS=[{n:'Pistol',rate:18,dmg:14,spr:.03,pel:1,spd:13,c:'#d0d0d0'},{n:'SMG',rate:6,dmg:8,spr:.09,pel:1,spd:14,c:'#4cc9f0'},{n:'Shotgun',rate:42,dmg:9,spr:.2,pel:6,spd:12,life:22,c:'#ff9e00'},{n:'Rifle',rate:11,dmg:19,spr:.025,pel:1,spd:17,c:'#b388ff'}];
  el.innerHTML=`<canvas width="${W}" height="${H}" tabindex="0"></canvas><div class="hud"><button id="bw">Wall (Q)</button><button id="bb">Box up (E)</button><button id="rs">Restart</button></div><div class="pad"><button data-d="U" aria-label="Up">▲</button><button data-d="L" aria-label="Left">◀</button><button data-d="D" aria-label="Down">▼</button><button data-d="R" aria-label="Right">▶</button></div><p class="empty">Move with WASD or the arrow keys. Aim with the mouse and hold the button to shoot (on a phone, touch and hold the map). Q builds a wall, E boxes you in. Shoot trees to collect materials, grab better weapons, and stay inside the storm circle. Last one standing wins.</p>`;
  const c=el.querySelector('canvas'),x=c.getContext('2d');
  let Wl,O,Fl,Lt,Bu,Pa,Pt,ents,P,S,cam,m={x:W/2,y:H/2},down=false,raf;
  const rp=f=>{const a=R()*TAU,d=Math.sqrt(R())*IR*f;return{x:WC+Math.cos(a)*d,y:WC+Math.sin(a)*d}};
  function blocked(px,py,r){
    if(Math.hypot(px-WC,py-WC)>IR-r)return true;
    for(let tx=(px-r)/T|0;tx<=(px+r)/T|0;tx++)for(let ty=(py-r)/T|0;ty<=(py+r)/T|0;ty++)if(Wl.has(ty*MW+tx)){const nx=Math.max(tx*T,Math.min(px,tx*T+T)),ny=Math.max(ty*T,Math.min(py,ty*T+T));if((nx-px)**2+(ny-py)**2<r*r)return true}
    for(const o of O)if((o.x-px)**2+(o.y-py)**2<(o.r+r)**2)return true;
    return false;
  }
  function mv(e,dx,dy){let ok=false;if(!blocked(e.x+dx,e.y,e.r)){e.x+=dx;ok=true}if(!blocked(e.x,e.y+dy,e.r)){e.y+=dy;ok=true}return ok}
  function mkLoot(px,py){const r=R();let k='g',g=0;if(r<.55){const q=R();g=q<.4?1:q<.75?2:3}else k=r<.8?'m':'s';return{x:px,y:py,k,g}}
  function boom(px,py,col,n){for(let i=0;i<n;i++){const a=R()*TAU,s=1+R()*3.5;Pa.push({x:px,y:py,vx:Math.cos(a)*s,vy:Math.sin(a)*s,l:24,c:col})}}
  function mkEnt(bot,i){let q;do{q=rp(.85)}while(blocked(q.x,q.y,14));return{x:q.x,y:q.y,r:14,hp:100,sh:0,g:0,cd:0,a:0,k:0,m:0,bot,col:bot?`hsl(${i*47%360},70%,55%)`:'#00e5ff',fl:0,wp:null,wt:0,sd:1,sdt:0,dead:false}}
  function nextPhase(){const st=S.st;st.i++;st.t=0;const ph=C.ph[st.i];if(!ph)return;st.r0=st.r;st.r1=ph.f*IR;st.x0=st.x;st.y0=st.y;const a=R()*TAU,d=R()*(st.r0-st.r1)*.8;st.x1=st.x0+Math.cos(a)*d;st.y1=st.y0+Math.sin(a)*d}
  function init(){
    Wl=new Map();O=[];Fl=[];Lt=[];Bu=[];Pa=[];Pt=[];
    S={f:0,over:false,win:false,sh:0,rank:0,st:{i:-1,t:0,r:C.ph.length?IR*1.15:IR*2,x:WC,y:WC}};nextPhase();
    for(let i=0;i<160;i++){const q=rp(.95);Pt.push({x:q.x,y:q.y,r:40+R()*70})}
    for(let i=0;i<C.trees+C.rocks;i++){const q=rp(.9),t=i<C.trees;O.push({x:q.x,y:q.y,r:t?20:24,hp:t?4:1e9,k:t?'t':'r'})}
    const hf=WS<2000?.45:.7;
    for(let h=0;h<C.houses;h++)for(let tr=0;tr<30;tr++){
      const q=rp(hf),w=5+(R()*3|0),hh=4+(R()*2|0),tx=q.x/T|0,ty=q.y/T|0;
      if(Fl.some(f=>Math.abs(f.tx-tx)<10&&Math.abs(f.ty-ty)<9))continue;
      Fl.push({tx,ty,w,h:hh});
      for(let i=0;i<w;i++)for(let j=0;j<hh;j++)if((i==0||j==0||i==w-1||j==hh-1)&&!(j==hh-1&&(i==(w>>1)||i==(w>>1)-1)))Wl.set((ty+j)*MW+tx+i,{hp:150,max:150});
      Lt.push(mkLoot((tx+1.5)*T,(ty+1.5)*T),mkLoot((tx+w-1.5)*T,(ty+1.5)*T));break;
    }
    O=O.filter(o=>!Fl.some(f=>o.x>f.tx*T-30&&o.x<(f.tx+f.w)*T+30&&o.y>f.ty*T-30&&o.y<(f.ty+f.h)*T+30));
    for(let i=0;i<C.loot;i++){const q=rp(.9);Lt.push(mkLoot(q.x,q.y))}
    ents=[mkEnt(0,0)];P=ents[0];P.m=C.mats;for(let i=0;i<C.bots;i++)ents.push(mkEnt(1,i+1));
    cam={x:P.x-W/2,y:P.y-H/2};
  }
  function put(tx,ty,ig){
    const k=ty*MW+tx;if(tx<0||ty<0||tx>=MW||ty>=MW||Wl.has(k))return false;
    const cx=(tx+.5)*T,cy=(ty+.5)*T;if(Math.hypot(cx-WC,cy-WC)>IR-20)return false;
    for(const e of ents)if(e!==ig&&!e.dead&&Math.abs(e.x-cx)<T/2+e.r&&Math.abs(e.y-cy)<T/2+e.r)return false;
    for(const o of O)if(Math.abs(o.x-cx)<T/2+o.r&&Math.abs(o.y-cy)<T/2+o.r)return false;
    Wl.set(k,{hp:120,max:120});return true;
  }
  function buildWall(){
    if(S.over||P.m<10)return;
    for(const d of[1.1,1.7]){if(put((P.x+Math.cos(P.a)*T*d)/T|0,(P.y+Math.sin(P.a)*T*d)/T|0,null)){P.m-=10;return}}
  }
  function box(){
    if(S.over||P.m<40)return;
    const cx=P.x/T|0,cy=P.y/T|0,px=(cx+.5)*T,py=(cy+.5)*T;if(blocked(px,py,P.r))return;
    P.x=px;P.y=py;let n=0;for(let i=-1;i<=1;i++)for(let j=-1;j<=1;j++)if((i||j)&&put(cx+i,cy+j,P))n++;
    if(n)P.m-=40;
  }
  function fire(e,a){
    if(e.cd>0)return;const g=GUNS[e.g];e.cd=g.rate;
    for(let i=0;i<g.pel;i++){const t=a+(R()-.5)*2*g.spr;Bu.push({x:e.x+Math.cos(t)*(e.r+4),y:e.y+Math.sin(t)*(e.r+4),vx:Math.cos(t)*g.spd,vy:Math.sin(t)*g.spd,d:g.dmg,o:e,l:g.life||50})}
    boom(e.x+Math.cos(a)*24,e.y+Math.sin(a)*24,'#ffe28a',2);
  }
  function die(e,src){
    if(e.dead)return;e.dead=true;boom(e.x,e.y,e.col,26);if(src)src.k++;
    Lt.push({x:e.x,y:e.y,k:'g',g:Math.max(1,e.g)});if(R()<.5)Lt.push({x:e.x+16,y:e.y,k:'s',g:0});
    if(e===P){S.over=true;S.rank=ents.filter(q=>!q.dead).length+1}
  }
  function hit(e,d,src){
    if(S.f<90&&e.bot)return;
    if(e.sh>0){const t=Math.min(e.sh,d);e.sh-=t;d-=t}
    e.hp-=d;e.fl=6;boom(e.x,e.y,'#ff4d6d',3);if(e===P)S.sh=Math.max(S.sh,6);
    if(e.hp<=0)die(e,src);
  }
  function pick(e){
    for(const l of Lt){
      if(l.dead||(l.x-e.x)**2+(l.y-e.y)**2>676)continue;
      if(l.k=='g'){if(l.g>e.g){e.g=l.g;l.dead=1}}
      else if(l.k=='m'){if(e.hp<100){e.hp=Math.min(100,e.hp+40);l.dead=1}}
      else if(e.sh<100){e.sh=Math.min(100,e.sh+50);l.dead=1}
    }
  }
  function bot(b){
    if(S.f<90)return;
    let t=null,td=460;for(const e of ents)if(!e.dead&&e!==b){const d=Math.hypot(e.x-b.x,e.y-b.y);if(d<td){td=d;t=e}}
    const st=S.st,out=Math.hypot(b.x-st.x,b.y-st.y)>st.r-80;let vx=0,vy=0,sp=2.1;
    if(out){const a=Math.atan2(st.y-b.y,st.x-b.x);vx=Math.cos(a);vy=Math.sin(a);sp=2.5;b.a=a}
    else if(t){
      const a=Math.atan2(t.y-b.y,t.x-b.x);b.a=a+(R()-.5)*C.acc;
      if(--b.sdt<=0){b.sd=R()<.5?1:-1;b.sdt=60+R()*80}
      if(td>260){vx=Math.cos(a);vy=Math.sin(a)}else if(td<150){vx=-Math.cos(a);vy=-Math.sin(a)}else{vx=-Math.sin(a)*b.sd;vy=Math.cos(a)*b.sd}
      if(td<430&&R()<.5)fire(b,b.a);
    }else{
      if(!b.wp||--b.wt<=0||Math.hypot(b.wp.x-b.x,b.wp.y-b.y)<30){b.wp=rp(.85);b.wt=300}
      const a=Math.atan2(b.wp.y-b.y,b.wp.x-b.x);vx=Math.cos(a);vy=Math.sin(a);b.a=a;
    }
    if(!mv(b,vx*sp,vy*sp)){b.wp=null;if(R()<.05)b.sd*=-1}
  }
  function update(){
    S.f++;const st=S.st,ph=C.ph[st.i];
    if(ph){st.t++;if(st.t>ph.w){const k=Math.min(1,(st.t-ph.w)/ph.s);st.r=st.r0+(st.r1-st.r0)*k;st.x=st.x0+(st.x1-st.x0)*k;st.y=st.y0+(st.y1-st.y0)*k;if(k>=1)nextPhase()}}
    if(C.inf)P.m=Math.min(999,P.m+.4);
    const kx=(K.d||K.arrowright?1:0)-(K.a||K.arrowleft?1:0),ky=(K.s||K.arrowdown?1:0)-(K.w||K.arrowup?1:0),l=Math.hypot(kx,ky)||1;
    mv(P,kx/l*3.2,ky/l*3.2);P.a=Math.atan2(cam.y+m.y-P.y,cam.x+m.x-P.x);if(down)fire(P,P.a);
    for(const e of ents){
      if(e.dead)continue;e.cd--;e.fl--;if(e.bot)bot(e);pick(e);
      if(Math.hypot(e.x-st.x,e.y-st.y)>st.r&&S.f%30==0){e.hp-=C.sd||2;e.fl=6;if(e.hp<=0)die(e,null)}
    }
    for(const b of Bu){
      for(let s=0;s<2&&!b.dead;s++){
        b.x+=b.vx/2;b.y+=b.vy/2;
        if(b.x<0||b.y<0||b.x>=WS||b.y>=WS){b.dead=1;break}
        const k=(b.y/T|0)*MW+(b.x/T|0),w=Wl.get(k);
        if(w){w.hp-=b.d;b.dead=1;boom(b.x,b.y,'#d9b382',3);if(w.hp<=0)Wl.delete(k);break}
        for(const o of O)if((o.x-b.x)**2+(o.y-b.y)**2<o.r*o.r){b.dead=1;boom(b.x,b.y,'#9ad17a',3);if(o.k=='t'){o.hp--;if(b.o===P)P.m+=5;if(o.hp<=0){o.dead=1;if(b.o===P)P.m+=20}}break}
        if(b.dead)break;
        for(const e of ents)if(!e.dead&&e!==b.o&&(e.x-b.x)**2+(e.y-b.y)**2<(e.r+2)**2){b.dead=1;hit(e,b.d,b.o);break}
      }
      if(--b.l<=0)b.dead=1;
    }
    Bu=Bu.filter(b=>!b.dead);O=O.filter(o=>!o.dead);Lt=Lt.filter(q=>!q.dead);
    Pa.forEach(q=>{q.x+=q.vx;q.y+=q.vy;q.vx*=.93;q.vy*=.93;q.l--});Pa=Pa.filter(q=>q.l>0);
    S.sh*=.85;
    if(!S.over&&ents.filter(e=>!e.dead).length<=1){S.over=true;S.win=!P.dead}
  }
  function bar(bx,by,w,h,v,col){x.fillStyle='rgba(0,0,0,.5)';x.fillRect(bx,by,w,h);x.fillStyle=col;x.fillRect(bx,by,w*Math.max(0,Math.min(1,v)),h)}
  function draw(){
    x.save();x.fillStyle=th.water;x.fillRect(0,0,W,H);
    x.translate(-cam.x+(R()-.5)*S.sh,-cam.y+(R()-.5)*S.sh);
    x.fillStyle=th.sand;x.beginPath();x.arc(WC,WC,IR+30,0,TAU);x.fill();
    x.fillStyle=th.g1;x.beginPath();x.arc(WC,WC,IR-50,0,TAU);x.fill();
    x.fillStyle=th.g2;for(const q of Pt)if(q.x>cam.x-120&&q.x<cam.x+W+120&&q.y>cam.y-120&&q.y<cam.y+H+120){x.beginPath();x.arc(q.x,q.y,q.r,0,TAU);x.fill()}
    x.fillStyle=th.floor;for(const f of Fl)x.fillRect(f.tx*T,f.ty*T,f.w*T,f.h*T);
    for(const l of Lt){
      if(l.x<cam.x-30||l.x>cam.x+W+30||l.y<cam.y-30||l.y>cam.y+H+30)continue;
      x.save();x.translate(l.x,l.y);x.shadowBlur=12;
      if(l.k=='g'){x.shadowColor=x.fillStyle=GUNS[l.g].c;x.fillRect(-11,-5,22,10)}
      else if(l.k=='m'){x.shadowColor=x.fillStyle='#ff4d6d';x.fillRect(-9,-3,18,6);x.fillRect(-3,-9,6,18)}
      else{x.shadowColor=x.fillStyle='#4cc9f0';x.beginPath();x.arc(0,0,8,0,TAU);x.fill()}
      x.restore();
    }
    for(const o of O){
      if(o.x<cam.x-40||o.x>cam.x+W+40||o.y<cam.y-40||o.y>cam.y+H+40)continue;
      x.fillStyle=o.k=='t'?th.tree:th.rock;x.beginPath();x.arc(o.x,o.y,o.r,0,TAU);x.fill();
      x.fillStyle='rgba(255,255,255,.18)';x.beginPath();x.arc(o.x-o.r*.25,o.y-o.r*.25,o.r*.55,0,TAU);x.fill();
    }
    const x0=Math.max(0,cam.x/T|0),x1=Math.min(MW-1,(cam.x+W)/T|0),y0=Math.max(0,cam.y/T|0),y1=Math.min(MW-1,(cam.y+H)/T|0);
    for(let ty=y0;ty<=y1;ty++)for(let tx=x0;tx<=x1;tx++){
      const w=Wl.get(ty*MW+tx);if(!w)continue;
      x.fillStyle=th.wall;x.fillRect(tx*T+1,ty*T+1,T-2,T-2);
      x.fillStyle=`rgba(0,0,0,${.45*(1-w.hp/w.max)})`;x.fillRect(tx*T+1,ty*T+1,T-2,T-2);
      x.strokeStyle='rgba(0,0,0,.35)';x.lineWidth=2;x.strokeRect(tx*T+2,ty*T+2,T-4,T-4);
    }
    x.lineCap='round';x.lineWidth=3;x.shadowBlur=10;x.shadowColor=x.strokeStyle='#fff3a0';
    for(const b of Bu){x.beginPath();x.moveTo(b.x,b.y);x.lineTo(b.x-b.vx*1.3,b.y-b.vy*1.3);x.stroke()}
    x.shadowBlur=0;
    for(const e of ents){
      if(e.dead)continue;
      x.save();x.translate(e.x,e.y);x.rotate(e.a);
      x.fillStyle=GUNS[e.g].c;x.fillRect(6,-3,20,6);
      x.fillStyle=e.fl>0?'#fff':e.col;x.strokeStyle='rgba(0,0,0,.55)';x.lineWidth=3;x.beginPath();x.arc(0,0,e.r,0,TAU);x.fill();x.stroke();
      x.fillStyle='rgba(255,255,255,.85)';x.beginPath();x.arc(5,-5,3,0,TAU);x.arc(5,5,3,0,TAU);x.fill();
      x.restore();
      if(e!==P){bar(e.x-16,e.y-26,32,4,e.hp/100,'#8ef08e');if(e.sh>0)bar(e.x-16,e.y-31,32,3,e.sh/100,'#4cc9f0')}
    }
    x.globalCompositeOperation='lighter';for(const q of Pa){x.globalAlpha=q.l/24;x.fillStyle=q.c;x.fillRect(q.x,q.y,3,3)}x.globalCompositeOperation='source-over';x.globalAlpha=1;
    const st=S.st;x.beginPath();x.rect(cam.x-80,cam.y-80,W+160,H+160);x.arc(st.x,st.y,st.r,0,TAU);x.fillStyle=th.storm;x.fill('evenodd');
    x.strokeStyle=th.storm.replace(/[\d.]+\)$/,'.9)');x.lineWidth=4;x.beginPath();x.arc(st.x,st.y,st.r,0,TAU);x.stroke();
    x.restore();
    const alive=ents.filter(e=>!e.dead).length,ph=C.ph[st.i];
    x.textAlign='center';x.font='700 15px sans-serif';x.fillStyle='rgba(0,0,0,.5)';x.fillRect(W/2-120,8,240,ph?44:24);x.fillStyle='#fff';
    x.fillText(`Alive ${alive}   Eliminations ${P.k}`,W/2,25);
    if(ph){x.font='600 13px sans-serif';x.fillText(st.t<ph.w?`Storm closes in ${Math.ceil((ph.w-st.t)/60)}s`:'Storm is closing',W/2,44)}
    bar(14,H-48,170,12,P.hp/100,'#8ef08e');bar(14,H-32,170,8,P.sh/100,'#4cc9f0');
    x.textAlign='left';x.font='700 14px sans-serif';x.fillStyle='#fff';x.fillText(`${GUNS[P.g].n}   Materials ${Math.floor(P.m)}`,14,H-58);
    const ms=100,mx0=W-ms-10,my0=10,s=ms/WS;
    x.fillStyle='rgba(0,0,0,.5)';x.fillRect(mx0,my0,ms,ms);x.fillStyle=th.g1;x.beginPath();x.arc(mx0+WC*s,my0+WC*s,IR*s,0,TAU);x.fill();
    x.strokeStyle='#c77dff';x.lineWidth=1.5;x.beginPath();x.arc(mx0+st.x*s,my0+st.y*s,Math.max(1,st.r*s),0,TAU);x.stroke();
    x.fillStyle='#00e5ff';x.fillRect(mx0+P.x*s-2,my0+P.y*s-2,4,4);
    if(S.over){x.fillStyle='rgba(0,0,0,.6)';x.fillRect(0,0,W,H);x.fillStyle='#fff';x.textAlign='center';x.font='800 34px sans-serif';x.fillText(S.win?'You won!':`Eliminated, #${S.rank}`,W/2,H/2-6);x.font='16px sans-serif';x.fillText(`${P.k} eliminations. Press Restart to play again.`,W/2,H/2+24)}
  }
  function tick(){
    if(!S.over)update();else{Pa.forEach(q=>{q.x+=q.vx;q.y+=q.vy;q.l--});Pa=Pa.filter(q=>q.l>0)}
    cam.x+=(Math.max(-60,Math.min(WS-W+60,P.x-W/2))-cam.x)*.15;cam.y+=(Math.max(-60,Math.min(WS-H+60,P.y-H/2))-cam.y)*.15;
    draw();raf=requestAnimationFrame(tick);
  }
  const kd=e=>{const k=e.key.toLowerCase();K[k]=1;if(k=='q')buildWall();if(k=='e')box();if(k.startsWith('arrow')||k==' ')e.preventDefault()},ku=e=>{K[e.key.toLowerCase()]=0};
  const pm=e=>{const r=c.getBoundingClientRect();m.x=(e.clientX-r.left)*W/r.width;m.y=(e.clientY-r.top)*H/r.height};
  const pu=()=>{down=false};
  document.addEventListener('keydown',kd);document.addEventListener('keyup',ku);document.addEventListener('pointerup',pu);
  c.addEventListener('pointermove',pm);c.addEventListener('pointerdown',e=>{pm(e);down=true});
  el.querySelectorAll('.pad button').forEach(b=>{const k={U:'w',L:'a',D:'s',R:'d'}[b.dataset.d];b.addEventListener('pointerdown',e=>{e.preventDefault();K[k]=1});['pointerup','pointerleave','pointercancel'].forEach(t=>b.addEventListener(t,()=>{K[k]=0}))});
  $('#bw').onclick=buildWall;$('#bb').onclick=box;$('#rs').onclick=init;
  init();tick();el._s=()=>({S,P,ents,Wl});
  return()=>{cancelAnimationFrame(raf);document.removeEventListener('keydown',kd);document.removeEventListener('keyup',ku);document.removeEventListener('pointerup',pu)};
}
const UB_LEVELS=[{"p":[[0,2,2,1],[2,5,2,1],[2,4,3,1],[4,3,2,1],[0,0,2,1],[2,1,3,0],[3,0,2,0]],"par":4},{"p":[[2,2,2,1],[1,0,3,1],[4,3,2,1],[4,0,2,1],[3,3,3,0],[2,3,2,0],[3,1,2,1],[5,1,2,0]],"par":4},{"p":[[0,2,2,1],[1,0,2,0],[4,1,2,1],[4,5,2,1],[1,5,2,1],[2,1,2,1],[2,0,2,1],[0,3,3,1],[3,4,3,1],[4,2,2,0],[3,2,2,0],[0,0,2,0]],"par":4},{"p":[[2,2,2,1],[3,4,2,0],[5,0,2,0],[2,3,3,0],[0,5,2,1],[1,1,2,0],[5,2,2,0],[0,3,2,0],[3,1,2,1],[4,2,2,0],[0,0,3,0],[4,4,2,0]],"par":4},{"p":[[2,2,2,1],[1,2,3,0],[3,4,2,0],[4,3,2,0],[5,2,3,0],[1,0,2,1],[4,5,2,1],[2,1,3,1],[0,3,2,0],[0,0,3,0]],"par":4},{"p":[[0,2,2,1],[4,1,2,0],[3,2,2,0],[5,2,2,0],[0,1,2,1],[2,1,2,1]],"par":4},{"p":[[2,2,2,1],[0,2,2,0],[4,1,2,0],[2,1,2,1],[5,1,2,0],[0,4,2,0],[4,4,2,1],[4,3,2,1],[2,0,3,1],[0,1,2,1]],"par":4},{"p":[[0,2,2,1],[1,1,2,1],[0,3,3,0],[1,4,2,0],[5,3,2,0],[3,3,2,1],[2,4,2,0],[3,1,2,0],[5,1,2,0],[4,1,2,0]],"par":4},{"p":[[1,2,2,1],[0,3,2,1],[3,4,2,1],[3,0,3,0],[2,3,2,0],[5,3,2,0]],"par":4},{"p":[[2,2,2,1],[0,0,2,0],[4,2,2,0],[3,1,2,1],[5,2,2,0],[0,4,2,0],[3,4,2,1],[0,3,2,1],[1,0,3,1],[1,1,2,1]],"par":4},{"p":[[1,2,2,1],[3,4,2,1],[3,2,2,0],[3,0,2,0],[4,3,2,1],[5,1,2,0],[0,1,2,1],[2,5,2,1],[2,0,2,0],[1,3,2,0]],"par":4},{"p":[[0,2,2,1],[4,5,2,1],[2,2,2,0],[0,0,3,1],[4,0,2,1],[3,1,2,1],[3,3,2,1],[5,2,3,0]],"par":4},{"p":[[1,2,2,1],[3,2,2,0],[3,0,2,0],[2,4,2,1],[3,5,2,1],[0,4,2,0],[0,0,3,1],[5,3,2,0],[4,2,2,0],[0,3,2,1],[0,1,2,0]],"par":4},{"p":[[1,2,2,1],[3,3,2,1],[3,1,2,0],[2,4,2,1],[0,0,3,1],[3,0,3,1],[1,4,2,0],[0,1,3,1]],"par":4},{"p":[[1,2,2,1],[0,1,3,1],[1,0,2,1],[0,4,2,1],[4,1,2,0],[3,0,2,1],[2,4,2,0],[5,1,3,0],[3,3,2,1]],"par":4},{"p":[[0,2,2,1],[1,0,2,0],[2,1,2,0],[4,4,2,1],[3,2,2,0],[5,2,2,0],[3,4,2,0]],"par":4},{"p":[[1,2,2,1],[2,4,2,0],[4,4,2,1],[5,1,2,0],[1,4,2,0],[4,2,2,0],[3,1,2,0],[1,0,2,1]],"par":4},{"p":[[1,2,2,1],[4,0,2,1],[0,0,3,0],[1,0,2,0],[2,0,2,1],[3,1,3,0],[2,4,2,0],[5,2,2,0],[3,5,2,1],[0,3,3,0]],"par":4},{"p":[[0,2,2,1],[1,5,3,1],[2,4,2,1],[0,0,2,0],[5,3,2,0],[2,1,3,0],[0,3,2,0]],"par":4},{"p":[[1,2,2,1],[3,3,3,0],[3,1,2,0],[1,0,3,1],[0,5,2,1],[4,1,2,0]],"par":4},{"p":[[0,2,2,1],[3,2,2,0],[2,0,2,1],[1,1,3,1],[5,1,2,0],[3,4,2,0],[0,3,2,0]],"par":5},{"p":[[2,2,2,1],[0,4,2,0],[3,3,2,0],[1,1,2,1],[1,2,2,0],[2,4,2,0],[0,1,3,0],[5,1,3,0],[1,4,2,0],[4,0,3,0],[4,5,2,1],[0,0,2,1]],"par":5},{"p":[[0,2,2,1],[3,4,3,1],[3,3,2,1],[2,2,3,0],[2,5,2,1],[0,1,2,1],[5,1,2,0],[2,0,2,0],[0,4,2,0],[3,0,2,1],[4,5,2,1]],"par":5},{"p":[[2,2,2,1],[3,1,3,1],[1,4,2,1],[0,1,2,1],[3,4,2,0],[4,3,2,0],[5,2,2,0],[5,4,2,0],[2,0,2,0],[0,5,3,1],[1,2,2,0],[0,2,2,0]],"par":5},{"p":[[2,2,2,1],[0,0,3,1],[2,4,2,1],[4,2,3,0],[1,4,2,0],[0,2,3,0],[1,2,2,0],[3,0,2,0],[2,5,3,1],[4,1,2,1]],"par":5},{"p":[[0,2,2,1],[3,0,2,1],[2,2,2,0],[3,4,2,0],[5,4,2,0],[2,1,2,1],[0,0,2,0],[0,5,2,1],[3,2,2,0],[0,3,2,0]],"par":5},{"p":[[0,2,2,1],[2,2,2,0],[0,5,2,1],[2,0,2,1],[3,3,3,1],[4,1,2,0],[5,4,2,0],[3,1,2,0],[3,4,2,0]],"par":5},{"p":[[0,2,2,1],[2,5,3,1],[1,4,2,1],[0,0,2,0],[5,4,2,0],[2,0,3,0],[0,3,2,0]],"par":5},{"p":[[2,2,2,1],[2,0,2,1],[3,1,3,1],[4,3,2,0],[0,4,2,1],[1,3,2,1],[0,1,2,0],[3,3,2,0],[5,2,2,0],[1,1,2,0],[5,4,2,0],[4,0,2,1]],"par":5},{"p":[[0,2,2,1],[2,2,2,0],[2,4,2,1],[3,0,2,1],[3,5,3,1],[2,0,2,0],[4,4,2,1],[3,1,3,0]],"par":5},{"p":[[0,2,2,1],[1,4,2,0],[2,1,2,0],[2,5,2,1],[1,0,2,1],[3,1,3,0],[3,4,2,1],[4,0,2,0],[0,3,2,1]],"par":5},{"p":[[2,2,2,1],[1,4,2,0],[1,0,3,1],[4,1,2,0],[5,0,3,0],[0,2,3,0],[4,4,2,1],[1,1,2,0],[4,3,2,1],[0,0,2,0],[2,1,2,1],[2,5,2,1]],"par":5},{"p":[[1,2,2,1],[3,3,2,1],[4,0,3,0],[1,3,2,0],[5,1,3,0],[0,2,3,0],[2,3,2,0],[0,0,2,0],[3,4,2,0],[1,1,3,1]],"par":5},{"p":[[1,2,2,1],[3,3,3,1],[2,5,3,1],[4,1,2,0],[5,1,2,0],[0,4,2,0],[1,3,3,0],[0,1,2,1],[3,0,3,1],[3,4,2,1],[5,4,2,0],[3,1,2,0]],"par":5},{"p":[[2,2,2,1],[3,0,2,0],[4,3,2,0],[2,0,2,0],[4,0,2,1],[2,3,3,0],[0,2,2,0],[5,4,2,0],[5,2,2,0]],"par":5},{"p":[[0,2,2,1],[2,0,2,1],[3,4,2,1],[2,1,2,0],[1,4,2,0],[0,3,3,1],[4,2,2,0],[4,1,2,1],[0,0,2,0],[3,5,2,1],[0,4,2,0]],"par":5},{"p":[[0,2,2,1],[2,4,3,1],[0,1,2,1],[2,0,3,1],[1,5,2,1],[1,3,2,0],[4,2,2,0],[3,5,2,1],[4,1,2,1],[0,0,2,1]],"par":5},{"p":[[1,2,2,1],[0,1,3,0],[3,1,2,0],[4,1,2,1],[2,0,2,0],[3,4,2,1],[4,5,2,1],[2,5,2,1],[4,2,2,0],[2,3,2,1],[3,0,2,1],[1,3,3,0]],"par":5},{"p":[[0,2,2,1],[1,3,2,1],[2,4,3,1],[4,0,2,1],[2,0,2,0],[2,5,2,1],[4,5,2,1],[3,1,3,0],[4,2,2,0]],"par":5},{"p":[[0,2,2,1],[3,0,3,0],[4,5,2,1],[2,5,2,1],[4,1,2,0],[1,4,2,0],[0,1,2,1]],"par":5},{"p":[[0,2,2,1],[2,2,3,0],[3,1,2,0],[2,0,2,1],[1,0,2,0],[1,5,2,1],[0,4,2,0],[3,3,2,1]],"par":5},{"p":[[2,2,2,1],[0,0,3,1],[2,4,2,1],[4,2,3,0],[1,4,2,0],[0,3,3,0],[1,2,2,0],[3,0,2,0],[2,5,3,1],[4,1,2,1]],"par":5},{"p":[[0,2,2,1],[4,3,2,1],[1,3,2,1],[1,0,3,1],[3,1,2,0],[1,4,3,1],[4,4,2,0],[2,1,2,0],[1,5,2,1]],"par":5},{"p":[[0,2,2,1],[4,0,2,1],[0,3,3,0],[3,1,2,0],[2,0,2,1],[4,1,2,0],[1,3,3,0],[2,1,2,0],[3,3,3,0],[0,1,2,1]],"par":5},{"p":[[0,2,2,1],[5,1,2,0],[3,0,3,0],[4,1,2,0],[2,3,2,1]],"par":5},{"p":[[0,2,2,1],[3,3,2,1],[4,1,2,0],[2,1,2,0],[1,0,2,1],[5,1,2,0],[0,4,2,1],[3,4,2,0],[2,3,2,0],[0,5,3,1]],"par":5},{"p":[[1,2,2,1],[0,1,3,1],[1,0,2,1],[3,4,2,1],[4,2,2,0],[3,0,2,1],[2,3,2,0],[5,1,3,0],[0,3,2,1]],"par":5},{"p":[[1,2,2,1],[3,2,2,0],[1,1,3,1],[1,5,2,1],[2,4,3,1],[4,3,2,1],[0,0,2,1],[0,3,3,0],[5,0,3,0]],"par":5},{"p":[[0,2,2,1],[3,2,3,0],[1,0,2,0],[4,4,2,1],[0,3,3,0],[1,4,2,0],[3,5,3,1],[2,1,2,1]],"par":6},{"p":[[0,2,2,1],[2,4,2,0],[5,0,2,0],[2,0,3,1],[2,2,2,0],[1,0,2,0],[4,3,2,1],[4,4,2,0],[0,0,2,0],[2,1,2,1],[1,4,2,0],[0,3,3,0]],"par":6},{"p":[[0,2,2,1],[2,2,2,0],[3,2,2,0],[0,3,3,0],[1,4,2,1],[2,0,2,0],[3,4,2,0]],"par":6},{"p":[[1,2,2,1],[0,1,2,0],[2,5,3,1],[2,4,2,1],[4,0,3,0],[2,1,2,1],[0,3,2,0],[5,1,2,0],[1,3,3,0]],"par":6},{"p":[[1,2,2,1],[1,4,2,0],[4,4,2,0],[2,4,2,1],[3,2,2,0],[0,4,2,0],[1,0,2,1],[0,1,3,0],[4,0,2,1],[1,1,3,1]],"par":6},{"p":[[0,2,2,1],[2,3,2,1],[0,3,2,1],[3,0,3,1],[3,1,2,0],[3,4,3,1],[4,2,2,0],[2,1,2,0],[0,5,2,1]],"par":6},{"p":[[2,2,2,1],[3,3,3,0],[3,0,2,1],[2,0,2,0],[0,1,2,0],[4,4,2,1],[5,0,3,0]],"par":6},{"p":[[1,2,2,1],[3,0,2,1],[0,3,2,1],[5,2,3,0],[1,0,2,1],[1,4,2,1],[3,1,3,1],[3,5,3,1],[0,1,3,1],[4,2,2,0],[3,4,2,1]],"par":6},{"p":[[0,2,2,1],[2,4,2,0],[5,0,2,0],[2,0,3,1],[2,2,2,0],[1,0,2,0],[4,3,2,1],[4,4,2,0],[0,0,2,0],[2,1,2,1],[1,3,2,0],[0,3,3,0]],"par":6},{"p":[[2,2,2,1],[0,2,2,0],[2,5,3,1],[3,4,2,1],[4,0,3,0],[0,1,2,1],[0,4,2,0],[5,2,2,0],[1,3,3,0]],"par":6},{"p":[[1,2,2,1],[0,1,2,1],[1,3,3,1],[1,4,2,0],[5,3,2,0],[0,0,3,1],[0,2,2,0],[4,3,2,0],[3,0,3,0],[5,1,2,0],[0,4,2,0]],"par":6},{"p":[[1,2,2,1],[2,4,3,1],[4,2,2,0],[0,1,2,1],[2,0,2,1],[3,1,2,1],[0,3,3,1],[3,2,2,0],[0,4,2,0],[3,5,2,1],[1,5,2,1],[0,0,2,1]],"par":6},{"p":[[0,2,2,1],[2,2,2,0],[3,1,2,0],[0,3,3,0],[1,4,2,1],[2,0,2,0],[3,4,2,0]],"par":6},{"p":[[0,2,2,1],[3,2,2,0],[1,1,3,1],[2,5,3,1],[0,4,2,0],[0,0,2,0],[3,4,3,1],[4,3,2,1],[1,0,2,1],[0,3,2,1],[3,0,2,1]],"par":6},{"p":[[1,2,2,1],[2,4,3,1],[4,2,2,0],[0,1,2,1],[4,0,2,1],[3,1,2,1],[0,3,3,1],[3,2,2,0],[0,4,2,0],[4,5,2,1],[2,5,2,1],[2,0,2,1]],"par":6},{"p":[[0,2,2,1],[3,4,3,1],[4,3,2,1],[2,2,3,0],[1,5,2,1],[0,1,2,1],[5,1,2,0],[2,0,2,0],[0,4,2,0],[4,0,2,1],[3,5,2,1]],"par":6},{"p":[[0,2,2,1],[3,2,2,0],[2,2,2,0],[2,4,2,1],[2,0,2,1],[0,3,3,0],[4,4,2,1],[1,0,2,0],[2,1,3,1]],"par":6},{"p":[[0,2,2,1],[4,2,2,0],[3,1,3,0],[2,2,2,0],[3,5,3,1],[1,0,3,1],[1,4,2,0],[0,0,2,0],[4,1,2,1]],"par":6},{"p":[[1,2,2,1],[0,5,3,1],[3,3,2,0],[4,3,2,0],[1,3,2,1],[2,0,2,0],[4,1,2,0],[5,0,2,0],[3,0,2,1],[3,5,2,1],[0,1,2,1]],"par":6},{"p":[[0,2,2,1],[3,5,3,1],[3,0,3,0],[0,0,2,0],[2,4,2,0],[4,1,2,1],[2,1,2,0],[1,4,2,0],[1,0,2,0]],"par":6},{"p":[[1,2,2,1],[2,0,2,1],[3,4,3,1],[4,0,2,1],[4,5,2,1],[3,1,3,0],[2,3,2,0],[0,1,2,1]],"par":6},{"p":[[2,2,2,1],[4,4,2,1],[2,4,2,0],[4,2,2,0],[4,5,2,1],[0,0,3,0],[5,0,2,0],[2,0,3,1],[1,3,3,1],[1,0,2,0],[5,2,2,0]],"par":6},{"p":[[1,2,2,1],[1,3,2,0],[4,2,2,0],[3,4,2,1],[3,2,2,0],[0,4,2,0],[0,0,2,1],[0,1,3,0],[4,0,2,1],[3,1,3,1]],"par":6},{"p":[[0,2,2,1],[2,4,2,0],[0,0,2,0],[1,0,2,1],[1,4,2,0],[1,1,3,1],[0,3,2,1],[4,3,2,1],[3,4,2,0],[4,1,2,1],[3,2,2,0],[5,4,2,0]],"par":6},{"p":[[2,2,2,1],[0,5,3,1],[3,3,2,0],[4,3,2,0],[0,3,2,1],[2,0,2,0],[4,1,2,0],[5,2,2,0],[4,0,2,1],[4,5,2,1],[0,1,2,1]],"par":6},{"p":[[0,2,2,1],[0,0,2,1],[1,4,3,1],[2,0,2,1],[2,5,2,1],[3,1,3,0],[2,1,2,0],[4,1,2,1]],"par":6},{"p":[[0,2,2,1],[3,2,2,0],[1,1,3,1],[2,5,2,1],[1,4,3,1],[4,3,2,1],[2,0,2,1],[0,3,3,0],[5,0,3,0]],"par":6},{"p":[[2,2,2,1],[0,4,2,0],[3,4,2,0],[3,1,2,1],[1,1,2,0],[2,4,2,0],[0,1,3,0],[5,1,3,0],[1,4,2,0],[4,2,3,0],[4,5,2,1],[4,0,2,1]],"par":6},{"p":[[0,2,2,1],[0,4,2,0],[1,5,2,1],[2,4,3,1],[3,5,2,1],[4,3,2,1],[3,0,3,0],[5,0,2,0],[0,1,2,1],[0,0,2,1]],"par":6},{"p":[[1,2,2,1],[2,5,3,1],[3,2,2,0],[2,4,2,1],[1,3,2,0],[2,1,2,1],[4,3,2,1],[1,0,2,1],[4,1,2,0],[0,1,2,1],[3,0,2,1]],"par":6},{"p":[[0,2,2,1],[2,1,3,0],[2,0,3,1],[1,4,2,1],[0,3,2,0],[3,2,3,0],[5,3,2,0],[0,0,2,0]],"par":6},{"p":[[1,2,2,1],[3,0,2,1],[4,4,2,0],[4,1,2,0],[2,3,3,1],[0,1,2,1],[0,3,2,1],[1,4,2,0],[2,0,2,0],[5,0,2,0],[5,3,2,0]],"par":6},{"p":[[2,2,2,1],[4,4,2,1],[4,5,2,1],[2,4,2,1],[5,2,2,0],[1,3,2,1],[3,3,2,1],[4,0,2,1],[3,0,2,0],[1,4,2,0],[0,3,2,0],[0,1,2,0]],"par":6},{"p":[[0,2,2,1],[3,1,2,0],[1,3,3,0],[4,4,2,0],[0,1,2,1],[2,5,2,1],[5,1,2,0],[1,0,3,1],[2,3,3,1],[2,1,2,0],[0,4,2,0]],"par":6},{"p":[[2,2,2,1],[0,1,3,1],[2,0,2,1],[4,4,2,1],[4,1,2,0],[4,0,2,1],[2,4,2,0],[5,1,3,0],[3,3,2,1]],"par":6},{"p":[[1,2,2,1],[1,0,2,1],[3,0,3,1],[0,3,2,1],[5,1,2,0],[1,5,2,1],[4,4,2,1],[3,1,2,0],[0,0,2,0],[2,3,2,0],[4,5,2,1]],"par":6},{"p":[[1,2,2,1],[0,1,2,1],[2,3,3,1],[1,3,2,0],[5,3,2,0],[0,0,3,1],[0,2,2,0],[4,4,2,0],[3,0,3,0],[5,1,2,0],[0,4,2,0]],"par":7},{"p":[[0,2,2,1],[3,1,2,0],[0,5,2,1],[0,0,2,0],[0,3,2,0],[1,0,3,1],[2,1,2,0],[2,4,3,1]],"par":7},{"p":[[0,2,2,1],[4,3,2,0],[2,4,2,0],[2,0,2,0],[3,5,3,1],[1,0,2,0],[5,2,2,0],[3,2,3,0],[3,0,2,0],[5,0,2,0],[4,1,2,0],[1,4,2,0]],"par":7},{"p":[[0,2,2,1],[2,0,2,0],[4,5,2,1],[0,0,2,1],[0,5,2,1],[4,0,3,0],[2,3,2,0],[4,3,2,1],[5,1,2,0]],"par":7},{"p":[[1,2,2,1],[3,4,2,0],[3,1,2,0],[4,4,2,1],[1,5,2,1],[0,2,2,0],[3,0,3,1],[5,2,2,0],[4,2,2,0],[2,3,2,1],[0,0,2,0]],"par":7},{"p":[[1,2,2,1],[0,1,2,1],[3,3,3,1],[1,3,2,0],[5,4,2,0],[0,0,3,1],[0,2,2,0],[4,0,2,0],[3,0,3,0],[5,1,2,0],[0,4,2,0]],"par":7},{"p":[[1,2,2,1],[1,0,2,1],[3,4,3,1],[3,0,2,1],[2,5,2,1],[3,1,3,0],[2,3,2,0],[4,1,2,1]],"par":7},{"p":[[0,2,2,1],[3,0,3,1],[2,4,2,1],[5,3,2,0],[1,5,3,1],[3,1,2,0],[0,3,3,0],[2,2,2,0],[5,1,2,0],[4,3,2,0]],"par":7},{"p":[[0,2,2,1],[2,4,2,0],[0,4,2,1],[1,0,2,1],[3,5,3,1],[2,2,2,0],[3,4,2,1],[3,0,3,0]],"par":7},{"p":[[3,2,2,1],[4,4,2,1],[2,2,2,0],[2,1,3,1],[1,0,2,0],[1,4,3,1],[4,5,2,1],[0,4,2,0],[3,0,3,1],[5,1,3,0],[1,2,2,0],[0,1,2,0]],"par":7},{"p":[[0,2,2,1],[4,2,2,0],[2,3,2,0],[2,1,2,0],[2,5,3,1],[1,0,2,0],[5,4,2,0],[3,2,3,0],[3,0,2,0],[5,2,2,0],[4,0,2,0],[1,4,2,0]],"par":7},{"p":[[1,2,2,1],[3,1,3,0],[2,0,2,1],[2,4,2,0],[0,0,2,0],[3,4,2,1],[5,0,3,0]],"par":7},{"p":[[0,2,2,1],[2,3,3,1],[2,5,3,1],[4,1,2,0],[5,2,2,0],[0,0,2,0],[1,3,3,0],[1,1,2,1],[1,0,3,1],[3,4,2,1],[5,4,2,0],[3,1,2,0]],"par":7},{"p":[[0,2,2,1],[3,2,2,0],[2,0,2,1],[2,1,3,1],[5,2,2,0],[3,4,2,0],[0,0,2,0]],"par":7},{"p":[[2,2,2,1],[3,3,2,1],[4,4,2,0],[0,1,3,1],[4,1,2,0],[3,0,2,0],[2,5,2,1],[2,3,2,0],[0,3,2,1],[5,3,3,0],[4,0,2,1],[5,1,2,0]],"par":7},{"p":[[0,2,2,1],[1,0,3,1],[4,4,2,1],[5,2,2,0],[3,5,3,1],[3,3,2,0],[0,3,3,0],[2,1,2,0],[5,0,2,0],[4,1,2,0]],"par":7},{"p":[[0,2,2,1],[3,2,3,0],[2,0,2,1],[2,4,2,0],[0,0,2,0],[4,4,2,1],[5,0,3,0]],"par":7},{"p":[[0,2,2,1],[2,2,2,0],[0,3,2,1],[3,3,2,1],[3,4,2,1],[0,1,3,1],[0,4,2,0],[2,0,2,1],[2,4,2,0],[3,1,2,0]],"par":7},{"p":[[0,2,2,1],[5,3,2,0],[3,3,2,0],[2,1,2,0],[3,1,2,1],[0,4,2,0],[1,4,2,0],[2,5,3,1],[3,0,3,1],[5,1,2,0],[1,0,2,0],[4,2,3,0]],"par":7},{"p":[[1,2,2,1],[4,4,2,1],[2,4,2,0],[4,1,2,0],[4,5,2,1],[0,2,3,0],[5,0,2,0],[2,0,3,1],[1,3,3,1],[1,0,2,0],[5,2,2,0]],"par":7},{"p":[[2,2,2,1],[2,3,2,1],[2,5,2,1],[0,5,2,1],[0,4,2,1],[3,0,2,0],[4,4,2,0],[4,2,2,0],[0,0,3,0],[4,0,2,1],[1,2,2,0]],"par":7},{"p":[[1,2,2,1],[1,4,2,0],[4,3,2,0],[2,4,2,1],[3,2,2,0],[0,4,2,0],[1,0,2,1],[0,0,3,0],[3,0,2,1],[1,1,3,1]],"par":7},{"p":[[0,2,2,1],[1,1,2,1],[2,0,3,1],[1,3,3,0],[4,1,2,0],[0,3,3,0],[2,4,2,0],[3,3,2,1],[2,2,2,0],[5,2,3,0]],"par":7},{"p":[[1,2,2,1],[0,2,2,0],[2,5,3,1],[3,4,2,1],[4,1,3,0],[1,1,2,1],[0,4,2,0],[5,1,2,0],[1,3,3,0]],"par":7},{"p":[[1,2,2,1],[4,4,2,1],[2,4,2,0],[4,1,2,0],[4,5,2,1],[0,0,3,0],[5,0,2,0],[2,0,3,1],[2,3,3,1],[1,0,2,0],[5,2,2,0]],"par":7},{"p":[[0,2,2,1],[3,5,3,1],[3,2,3,0],[0,4,2,0],[2,4,2,0],[4,1,2,1],[2,1,2,0],[1,4,2,0],[1,0,2,0]],"par":7},{"p":[[0,2,2,1],[3,4,2,0],[3,1,2,0],[4,4,2,1],[1,5,2,1],[0,4,2,0],[3,0,3,1],[5,2,2,0],[4,1,2,0],[3,3,2,1],[0,0,2,0]],"par":7},{"p":[[1,2,2,1],[2,3,2,0],[3,4,3,1],[4,1,2,0],[3,1,3,0],[0,3,2,0]],"par":7},{"p":[[2,2,2,1],[1,0,3,1],[4,4,2,1],[5,2,2,0],[2,5,3,1],[3,3,2,0],[0,3,3,0],[2,3,2,0],[5,0,2,0],[4,1,2,0]],"par":7},{"p":[[0,2,2,1],[0,3,2,0],[1,0,2,0],[1,4,2,1],[5,4,2,0],[2,1,3,0],[4,3,2,0],[2,5,2,1],[3,1,3,0],[0,0,2,0]],"par":7},{"p":[[0,2,2,1],[2,0,3,0],[3,0,3,1],[1,4,2,1],[0,4,2,0],[3,3,3,0],[5,2,2,0],[0,0,2,0]],"par":7},{"p":[[1,2,2,1],[0,3,2,1],[3,5,3,1],[2,1,2,1],[3,2,3,0],[1,4,2,0]],"par":7},{"p":[[1,2,2,1],[2,0,2,1],[2,1,3,1],[4,3,2,0],[1,4,2,1],[1,3,2,1],[0,0,2,0],[3,2,2,0],[5,1,2,0],[1,0,2,0],[5,3,2,0],[4,0,2,1]],"par":7},{"p":[[0,2,2,1],[4,4,2,1],[2,0,3,1],[1,3,3,0],[2,5,2,1],[2,2,3,0],[3,2,2,0],[5,1,3,0]],"par":7},{"p":[[0,2,2,1],[3,2,2,0],[1,5,2,1],[0,0,2,0],[0,4,2,0],[2,0,3,1],[2,2,2,0],[1,4,3,1]],"par":7},{"p":[[2,2,2,1],[3,0,2,0],[4,3,2,1],[4,4,2,0],[1,0,2,0],[5,1,2,0],[4,1,2,0],[1,2,2,0],[0,4,2,0],[4,0,2,1]],"par":7},{"p":[[0,2,2,1],[2,1,2,0],[1,3,2,0],[2,3,3,1],[1,5,2,1],[3,4,2,1],[3,1,2,0],[3,0,3,1],[1,0,2,0]],"par":7},{"p":[[0,2,2,1],[2,3,2,0],[0,0,2,0],[1,0,2,1],[1,4,2,0],[1,1,3,1],[0,3,2,1],[4,3,2,1],[3,4,2,0],[4,1,2,1],[3,2,2,0],[5,4,2,0]],"par":7},{"p":[[0,2,2,1],[3,1,2,0],[3,5,2,1],[0,0,2,0],[0,4,2,0],[2,0,3,1],[2,1,2,0],[2,4,3,1]],"par":7},{"p":[[2,2,2,1],[2,0,2,0],[4,5,2,1],[0,0,2,1],[2,5,2,1],[4,0,3,0],[2,3,2,0],[3,3,2,1],[5,0,2,0]],"par":7},{"p":[[0,2,2,1],[1,4,3,1],[4,4,2,1],[4,5,2,1],[2,2,2,0],[5,0,2,0],[0,0,2,0],[0,4,2,0],[1,0,3,1]],"par":8},{"p":[[0,2,2,1],[2,3,2,0],[0,0,2,0],[2,0,2,1],[1,4,2,0],[1,1,3,1],[0,3,2,1],[4,3,2,1],[3,4,2,0],[4,1,2,1],[3,2,2,0],[5,4,2,0]],"par":8},{"p":[[3,2,2,1],[5,1,3,0],[0,1,2,1],[0,2,2,0],[4,5,2,1],[2,1,2,0],[3,3,3,0],[1,4,2,0],[4,0,2,0]],"par":8},{"p":[[0,2,2,1],[0,4,2,0],[1,0,2,0],[1,4,2,1],[5,2,2,0],[2,1,3,0],[4,4,2,0],[1,5,2,1],[3,3,3,0],[0,0,2,0]],"par":8},{"p":[[2,2,2,1],[3,0,2,0],[3,3,2,1],[4,4,2,0],[1,1,2,0],[5,2,2,0],[4,1,2,0],[1,3,2,0],[0,2,2,0],[4,0,2,1]],"par":8},{"p":[[0,2,2,1],[0,4,2,0],[1,0,2,0],[1,4,2,1],[5,3,2,0],[2,1,3,0],[4,2,2,0],[1,5,2,1],[3,3,3,0],[0,0,2,0]],"par":8},{"p":[[2,2,2,1],[5,3,2,0],[3,3,2,0],[2,3,2,0],[0,1,2,1],[0,3,2,0],[1,4,2,0],[3,5,3,1],[3,0,3,1],[5,1,2,0],[1,2,2,0],[4,2,3,0]],"par":8},{"p":[[1,2,2,1],[1,3,2,1],[4,1,2,0],[2,0,2,0],[4,0,2,1],[5,1,2,0],[4,4,2,1],[3,0,2,0],[2,4,2,0],[3,5,3,1]],"par":8},{"p":[[3,2,2,1],[4,4,2,1],[3,3,2,0],[4,5,2,1],[5,0,3,0],[2,1,2,0],[0,0,2,0],[1,3,2,0],[3,0,2,1],[0,4,2,0],[0,2,2,0]],"par":8},{"p":[[1,2,2,1],[3,5,2,1],[0,1,2,0],[1,4,2,1],[5,4,2,0],[1,3,2,1],[3,1,3,0],[4,3,2,1],[0,3,3,0],[3,4,2,1]],"par":8},{"p":[[0,2,2,1],[2,1,2,0],[3,0,2,0],[1,4,3,1],[0,3,2,1],[0,4,2,0],[1,5,3,1],[5,3,2,0],[3,2,2,0],[4,0,2,0],[5,1,2,0]],"par":8},{"p":[[2,2,2,1],[5,1,3,0],[3,1,2,1],[0,2,2,0],[4,5,2,1],[2,0,2,0],[3,3,3,0],[1,4,2,0],[4,2,2,0]],"par":8},{"p":[[1,2,2,1],[2,5,2,1],[0,0,2,0],[1,4,2,1],[5,4,2,0],[1,3,2,1],[3,1,3,0],[4,3,2,1],[0,3,3,0],[3,4,2,1]],"par":8},{"p":[[0,2,2,1],[2,1,2,1],[4,5,2,1],[5,3,2,0],[5,1,2,0],[0,3,2,0],[1,4,2,0],[3,4,2,1],[3,3,2,1],[4,0,3,0],[2,5,2,1],[0,1,2,1]],"par":8},{"p":[[2,2,2,1],[0,5,3,1],[3,0,2,0],[4,3,2,0],[2,3,2,1],[2,0,2,0],[4,1,2,0],[5,1,2,0],[4,0,2,1],[3,5,2,1],[0,1,2,1]],"par":8},{"p":[[0,2,2,1],[2,0,3,0],[3,0,3,1],[1,4,2,1],[0,4,2,0],[3,2,3,0],[5,3,2,0],[0,0,2,0]],"par":8},{"p":[[3,2,2,1],[5,1,2,0],[1,2,2,0],[5,4,2,0],[0,1,2,1],[2,0,3,0],[0,2,2,0],[3,0,2,0],[0,4,2,0],[2,5,2,1],[4,0,2,1]],"par":8},{"p":[[1,2,2,1],[2,5,2,1],[0,1,2,0],[1,4,2,1],[5,4,2,0],[2,3,2,1],[3,0,3,0],[4,3,2,1],[0,3,3,0],[3,4,2,1]],"par":8},{"p":[[2,2,2,1],[5,3,2,0],[3,3,2,0],[2,4,2,0],[0,1,2,1],[0,3,2,0],[1,4,2,0],[3,5,3,1],[0,0,3,1],[5,1,2,0],[1,2,2,0],[4,1,3,0]],"par":8},{"p":[[1,2,2,1],[4,3,2,1],[3,4,3,1],[3,0,2,1],[2,0,2,0],[0,5,2,1],[3,5,2,1],[3,1,3,0],[4,1,2,0]],"par":8},{"p":[[0,2,2,1],[1,1,2,1],[1,0,3,1],[1,3,3,0],[4,1,2,0],[0,3,3,0],[2,4,2,0],[4,3,2,1],[2,2,2,0],[5,0,3,0]],"par":8},{"p":[[3,2,2,1],[5,2,2,0],[1,0,2,0],[5,4,2,0],[4,1,2,1],[2,1,3,0],[0,0,2,0],[3,0,2,0],[0,2,2,0],[2,5,2,1],[4,0,2,1]],"par":8},{"p":[[3,2,2,1],[5,0,3,0],[1,1,2,1],[0,4,2,0],[4,5,2,1],[2,4,2,0],[3,3,3,0],[1,4,2,0],[4,0,2,0]],"par":8},{"p":[[0,2,2,1],[1,3,3,0],[5,0,2,0],[3,1,2,1],[2,3,3,0],[5,3,3,0],[0,4,2,0],[2,1,2,0],[0,0,2,1],[2,0,3,1],[3,3,2,1]],"par":8},{"p":[[0,2,2,1],[1,3,2,0],[3,2,2,0],[2,1,2,0],[0,0,2,0],[3,1,3,1],[4,2,3,0],[1,0,3,1],[3,4,2,0],[5,3,2,0]],"par":8},{"p":[[1,2,2,1],[2,1,2,1],[4,5,2,1],[5,3,2,0],[5,1,2,0],[0,4,2,0],[1,4,2,0],[2,4,2,1],[0,3,2,1],[4,0,3,0],[2,5,2,1],[0,1,2,1]],"par":8},{"p":[[1,2,2,1],[3,1,2,0],[2,4,2,0],[3,0,3,1],[0,0,3,0],[1,3,2,0],[4,1,2,0],[0,5,2,1],[5,3,2,0],[0,3,2,0],[3,4,2,0]],"par":8},{"p":[[0,2,2,1],[4,2,2,0],[3,0,2,0],[1,0,2,0],[4,5,2,1],[5,1,2,0],[2,5,2,1],[3,2,2,0],[0,3,2,0],[1,4,2,0],[3,4,2,1],[2,0,3,0]],"par":8},{"p":[[2,2,2,1],[1,1,2,1],[0,2,2,0],[1,2,3,0],[3,0,2,0],[2,4,3,1],[4,2,2,0],[1,5,3,1],[4,0,2,1],[0,4,2,0]],"par":8},{"p":[[2,2,2,1],[3,0,2,0],[3,3,2,1],[4,4,2,0],[1,0,2,0],[5,1,2,0],[4,1,2,0],[1,2,2,0],[0,4,2,0],[4,0,2,1]],"par":8},{"p":[[3,2,2,1],[5,2,2,0],[1,1,2,0],[5,4,2,0],[4,1,2,1],[2,2,3,0],[0,2,2,0],[3,0,2,0],[0,4,2,0],[3,5,2,1],[4,0,2,1]],"par":8},{"p":[[0,2,2,1],[2,1,2,1],[0,0,3,1],[1,3,3,0],[4,0,2,0],[0,3,3,0],[2,4,2,0],[3,3,2,1],[2,2,2,0],[5,0,3,0]],"par":8},{"p":[[0,2,2,1],[0,4,2,0],[1,5,2,1],[2,4,3,1],[3,5,2,1],[0,3,2,1],[3,0,3,0],[5,1,2,0],[1,1,2,1],[4,0,2,1]],"par":8},{"p":[[0,2,2,1],[4,3,2,0],[2,4,2,0],[2,1,2,0],[3,5,3,1],[1,0,2,0],[5,2,2,0],[3,2,3,0],[3,0,2,0],[5,0,2,0],[4,1,2,0],[1,4,2,0]],"par":8},{"p":[[1,2,2,1],[1,3,2,0],[3,2,2,0],[2,0,2,0],[0,0,2,0],[3,1,3,1],[4,2,3,0],[3,0,3,1],[3,4,2,0],[5,3,2,0]],"par":8},{"p":[[2,2,2,1],[4,4,2,1],[4,0,2,1],[0,2,2,0],[1,3,3,1],[0,5,2,1],[2,1,2,1],[1,0,3,1],[3,4,2,0],[4,2,2,0]],"par":8},{"p":[[2,2,2,1],[1,1,2,1],[0,0,2,0],[1,2,3,0],[3,0,2,0],[2,4,3,1],[4,2,2,0],[0,5,3,1],[4,0,2,1],[0,2,2,0]],"par":8},{"p":[[0,2,2,1],[2,1,2,0],[4,5,2,1],[0,0,2,1],[0,5,2,1],[4,0,3,0],[2,3,2,0],[3,3,2,1],[5,1,2,0]],"par":8},{"p":[[1,2,2,1],[4,5,2,1],[4,1,2,0],[2,3,2,0],[5,0,3,0],[4,3,2,1],[3,3,3,0],[1,1,2,1]],"par":8},{"p":[[0,2,2,1],[5,2,2,0],[3,1,3,1],[1,3,2,0],[3,5,2,1],[3,2,3,0],[1,1,2,1],[2,2,3,0],[0,3,3,0],[5,4,2,0]],"par":8},{"p":[[0,2,2,1],[0,0,2,0],[3,5,2,1],[5,4,2,0],[2,1,3,0],[1,4,3,1],[0,3,2,1],[3,2,2,0],[1,5,2,1],[0,4,2,0]],"par":9},{"p":[[0,2,2,1],[3,3,2,1],[2,2,2,0],[4,1,2,1],[1,5,2,1],[1,4,2,1],[4,5,2,1],[0,3,3,0],[1,0,2,1],[3,4,2,0],[1,1,3,1],[5,3,2,0]],"par":9},{"p":[[1,2,2,1],[2,1,2,1],[4,5,2,1],[5,3,2,0],[5,1,2,0],[0,4,2,0],[1,4,2,0],[3,4,2,1],[1,3,2,1],[4,0,3,0],[2,5,2,1],[0,1,2,1]],"par":9},{"p":[[1,2,2,1],[3,1,3,0],[0,4,2,0],[3,4,3,1],[2,3,2,0],[0,3,2,1],[3,5,3,1]],"par":9},{"p":[[0,2,2,1],[0,3,2,0],[0,5,2,1],[1,4,3,1],[2,5,2,1],[4,3,2,1],[3,1,3,0],[5,4,2,0],[4,1,2,1],[4,0,2,1]],"par":9},{"p":[[0,2,2,1],[2,4,2,0],[3,0,2,0],[3,4,3,1],[1,3,2,1],[0,3,2,0],[3,5,3,1],[5,2,2,0],[3,2,2,0],[4,0,2,0],[5,0,2,0]],"par":9},{"p":[[1,2,2,1],[2,4,2,0],[3,0,2,0],[3,4,3,1],[1,3,2,1],[0,3,2,0],[3,5,3,1],[5,2,2,0],[3,2,2,0],[4,1,2,0],[5,0,2,0]],"par":9},{"p":[[1,2,2,1],[4,1,2,1],[0,3,3,0],[3,5,2,1],[2,3,2,0],[2,1,2,1],[0,1,2,0],[3,4,2,1],[1,0,2,0],[2,0,2,1],[3,2,2,0],[5,4,2,0]],"par":9},{"p":[[1,2,2,1],[3,1,2,0],[4,2,2,0],[0,1,2,0],[2,4,2,0],[4,4,2,1],[5,1,2,0],[1,3,2,1],[1,0,2,0],[4,0,2,0]],"par":9},{"p":[[2,2,2,1],[1,1,2,0],[1,3,2,0],[5,1,2,0],[0,5,2,1],[4,0,2,1],[4,3,3,0],[3,4,2,0],[2,0,2,0],[4,1,2,0],[0,1,3,0]],"par":9},{"p":[[1,2,2,1],[1,3,2,0],[3,2,2,0],[2,0,2,0],[0,0,2,0],[3,1,3,1],[4,2,3,0],[3,0,3,1],[3,4,2,0],[5,2,2,0]],"par":9},{"p":[[0,2,2,1],[0,0,2,0],[4,5,2,1],[5,1,2,0],[2,1,3,0],[2,4,3,1],[0,3,2,1],[3,2,2,0],[2,5,2,1],[0,4,2,0]],"par":9},{"p":[[1,2,2,1],[1,0,2,0],[4,2,2,0],[3,3,2,0],[0,0,3,0],[4,4,2,1],[2,3,2,0],[3,1,2,0],[4,1,2,1],[4,5,2,1]],"par":9},{"p":[[1,2,2,1],[5,3,3,0],[1,1,3,1],[5,1,2,0],[4,3,2,0],[0,4,2,1],[1,3,2,1],[0,0,2,0],[0,2,2,0],[3,2,2,0],[2,4,2,1]],"par":9},{"p":[[1,2,2,1],[3,0,3,0],[0,4,2,0],[3,4,3,1],[2,3,2,0],[0,3,2,1],[2,5,3,1]],"par":9},{"p":[[1,2,2,1],[3,2,2,0],[4,2,2,0],[0,2,2,0],[2,4,2,0],[4,4,2,1],[5,2,2,0],[1,3,2,1],[1,4,2,0],[4,0,2,0]],"par":9},{"p":[[0,2,2,1],[3,3,2,1],[2,2,2,0],[4,1,2,1],[1,5,2,1],[1,4,2,1],[4,5,2,1],[0,3,3,0],[2,0,2,1],[3,4,2,0],[1,1,3,1],[5,3,2,0]],"par":9},{"p":[[0,2,2,1],[3,2,3,0],[4,3,2,0],[1,5,2,1],[1,4,2,1],[4,5,2,1],[0,4,2,0],[2,1,3,0],[0,0,3,1],[5,1,2,0],[0,1,2,1]],"par":9},{"p":[[2,2,2,1],[4,4,2,1],[1,0,3,0],[2,0,2,0],[0,5,2,1],[5,2,2,0],[4,1,2,0],[3,3,2,0],[0,1,3,0],[3,5,2,1],[5,0,2,0],[2,3,2,0]],"par":9},{"p":[[0,2,2,1],[5,2,2,0],[3,1,3,1],[1,3,2,0],[1,5,2,1],[3,3,3,0],[1,1,2,1],[2,2,3,0],[0,3,3,0],[5,4,2,0]],"par":9},{"p":[[0,2,2,1],[4,2,2,0],[3,0,2,0],[1,0,2,0],[4,5,2,1],[5,1,2,0],[2,5,2,1],[3,2,2,0],[0,4,2,0],[1,4,2,0],[3,4,2,1],[2,0,3,0]],"par":9},{"p":[[2,2,2,1],[3,4,2,0],[4,2,2,0],[0,3,2,0],[2,4,2,0],[4,4,2,1],[5,2,2,0],[1,3,2,1],[1,4,2,0],[4,0,2,0]],"par":9},{"p":[[2,2,2,1],[1,5,2,1],[4,1,2,0],[2,3,2,0],[5,0,3,0],[4,3,2,1],[3,3,3,0],[1,1,2,1]],"par":9},{"p":[[2,2,2,1],[4,5,2,1],[4,1,2,0],[2,4,2,0],[5,0,3,0],[4,3,2,1],[3,3,3,0],[1,1,2,1]],"par":9},{"p":[[1,2,2,1],[2,4,2,0],[1,3,2,0],[2,3,3,1],[0,5,2,1],[3,4,2,1],[3,1,2,0],[3,0,3,1],[1,0,2,0]],"par":9},{"p":[[0,2,2,1],[5,2,2,0],[3,1,3,1],[1,3,2,0],[1,5,2,1],[3,3,3,0],[0,1,2,1],[2,0,3,0],[0,3,3,0],[5,4,2,0]],"par":9},{"p":[[1,2,2,1],[3,1,3,0],[0,4,2,0],[3,4,3,1],[2,3,2,0],[0,3,2,1],[1,5,3,1]],"par":9},{"p":[[0,2,2,1],[3,3,2,1],[2,2,2,0],[4,1,2,1],[1,5,2,1],[1,4,2,1],[4,5,2,1],[0,3,3,0],[3,0,2,1],[3,4,2,0],[1,1,3,1],[5,3,2,0]],"par":9},{"p":[[0,2,2,1],[4,2,2,0],[3,0,2,0],[1,0,2,0],[4,5,2,1],[5,1,2,0],[2,5,2,1],[3,2,2,0],[0,4,2,0],[1,4,2,0],[3,4,2,1],[2,1,3,0]],"par":9},{"p":[[1,2,2,1],[2,4,2,0],[1,3,2,0],[2,3,3,1],[0,5,2,1],[3,4,2,1],[3,1,2,0],[2,0,3,1],[1,0,2,0]],"par":9},{"p":[[0,2,2,1],[1,3,3,0],[5,0,2,0],[3,1,2,1],[2,3,3,0],[5,2,3,0],[0,4,2,0],[2,1,2,0],[0,0,2,1],[2,0,3,1],[3,3,2,1]],"par":9},{"p":[[0,2,2,1],[0,0,2,0],[3,5,2,1],[5,1,2,0],[2,1,3,0],[2,4,3,1],[0,3,2,1],[3,2,2,0],[1,5,2,1],[0,4,2,0]],"par":9},{"p":[[0,2,2,1],[1,3,3,0],[5,0,2,0],[3,1,2,1],[2,3,3,0],[5,2,3,0],[0,3,2,0],[2,1,2,0],[0,0,2,1],[2,0,3,1],[3,3,2,1]],"par":9},{"p":[[3,2,2,1],[4,4,2,1],[1,1,3,0],[2,2,2,0],[0,5,2,1],[5,2,2,0],[4,0,2,0],[3,3,2,0],[0,1,3,0],[3,5,2,1],[5,0,2,0],[2,4,2,0]],"par":10},{"p":[[2,2,2,1],[0,5,2,1],[2,1,2,1],[4,4,2,1],[0,1,2,0],[3,4,2,0],[5,0,2,0],[2,3,2,0],[5,2,2,0],[1,1,2,0],[4,5,2,1],[0,3,2,1]],"par":10},{"p":[[3,2,2,1],[2,2,3,0],[2,0,2,1],[3,3,2,0],[0,0,2,1],[3,5,2,1],[2,1,2,1],[4,0,2,1],[4,4,2,1],[5,2,2,0],[0,5,2,1]],"par":10},{"p":[[2,2,2,1],[1,0,2,0],[1,2,2,0],[5,1,2,0],[0,5,2,1],[4,0,2,1],[4,3,3,0],[3,0,2,0],[2,0,2,0],[4,1,2,0],[0,0,3,0]],"par":10},{"p":[[0,2,2,1],[2,0,2,1],[4,4,2,0],[4,2,2,0],[2,3,3,0],[5,0,2,0],[1,0,2,0],[2,1,2,0],[0,3,3,0]],"par":10},{"p":[[1,2,2,1],[5,3,3,0],[2,1,3,1],[5,1,2,0],[4,4,2,0],[0,4,2,1],[1,3,2,1],[0,0,2,0],[0,2,2,0],[3,2,2,0],[2,4,2,1]],"par":10},{"p":[[0,2,2,1],[4,4,2,1],[3,4,2,0],[3,0,2,0],[2,3,2,1],[5,2,2,0],[4,1,2,1],[1,5,2,1],[2,1,2,0],[1,3,2,0]],"par":10},{"p":[[2,2,2,1],[1,1,2,0],[1,3,2,0],[5,1,2,0],[0,5,2,1],[4,0,2,1],[4,3,3,0],[3,0,2,0],[2,0,2,0],[4,1,2,0],[0,1,3,0]],"par":10},{"p":[[2,2,2,1],[4,4,2,1],[1,1,3,0],[2,0,2,0],[0,5,2,1],[5,2,2,0],[4,2,2,0],[3,3,2,0],[0,2,3,0],[3,5,2,1],[5,0,2,0],[2,4,2,0]],"par":10},{"p":[[0,2,2,1],[4,4,2,1],[3,4,2,0],[3,0,2,0],[3,3,2,1],[5,2,2,0],[4,1,2,1],[0,5,2,1],[2,2,2,0],[1,3,2,0]],"par":10},{"p":[[1,2,2,1],[5,2,3,0],[2,1,3,1],[5,0,2,0],[4,4,2,0],[0,4,2,1],[1,3,2,1],[0,0,2,0],[0,2,2,0],[3,2,2,0],[2,4,2,1]],"par":10},{"p":[[2,2,2,1],[4,0,2,1],[0,4,2,0],[3,0,2,0],[1,1,2,0],[1,4,3,1],[0,3,3,1],[4,1,2,0],[4,4,2,1],[3,5,3,1]],"par":10},{"p":[[1,2,2,1],[2,3,2,1],[4,5,2,1],[1,5,2,1],[4,4,2,1],[3,4,2,0],[4,2,2,0],[4,0,2,0],[0,2,3,0],[0,0,2,1],[1,3,2,0]],"par":10},{"p":[[0,2,2,1],[1,4,2,0],[2,0,2,0],[2,5,2,1],[3,0,2,1],[3,1,3,0],[2,4,2,1],[4,4,2,0],[4,3,2,1]],"par":10},{"p":[[0,2,2,1],[5,0,2,0],[3,5,3,1],[2,2,2,0],[3,1,2,0],[3,3,2,1],[2,4,3,1],[1,3,2,0],[0,0,2,0],[5,2,2,0],[1,0,3,1]],"par":11},{"p":[[0,2,2,1],[1,5,3,1],[3,3,2,0],[4,1,2,0],[1,3,2,0],[4,3,2,1],[4,4,2,0],[2,2,3,0],[2,1,2,1]],"par":11},{"p":[[0,2,2,1],[3,4,2,0],[4,4,2,1],[3,2,2,0],[3,1,2,1],[0,5,3,1],[3,0,2,1],[2,2,3,0],[4,2,2,0],[1,0,2,1]],"par":11},{"p":[[0,2,2,1],[4,0,3,0],[2,5,3,1],[4,3,2,1],[0,0,3,1],[5,1,2,0],[3,0,2,0],[3,4,3,1],[1,1,2,1],[2,2,2,0]],"par":11},{"p":[[1,2,2,1],[0,5,2,1],[4,1,2,1],[3,4,2,1],[0,0,2,0],[3,1,2,0],[5,2,2,0],[2,4,2,0],[5,4,2,0],[1,3,2,0],[3,5,2,1],[2,3,2,1]],"par":11},{"p":[[3,2,2,1],[4,5,2,1],[1,1,2,0],[2,1,2,0],[3,0,2,1],[3,3,2,0],[5,1,3,0],[4,4,2,1],[0,3,3,0],[0,0,2,0],[1,5,3,1]],"par":11},{"p":[[0,2,2,1],[4,4,2,1],[2,4,2,1],[4,0,2,1],[2,5,2,1],[2,0,2,1],[2,1,2,0],[0,0,2,0],[5,2,2,0],[1,0,2,0],[2,3,2,1],[4,2,2,0]],"par":11},{"p":[[0,2,2,1],[2,0,2,1],[4,4,2,0],[4,2,2,0],[2,3,3,0],[5,2,2,0],[1,0,2,0],[2,1,2,0],[0,3,3,0]],"par":11},{"p":[[1,2,2,1],[1,4,2,0],[2,0,2,0],[2,5,2,1],[3,0,2,1],[3,1,3,0],[2,4,2,1],[4,4,2,0],[4,3,2,1]],"par":11},{"p":[[0,2,2,1],[1,5,2,1],[5,0,2,0],[4,4,2,1],[3,1,3,0],[0,3,2,1],[0,4,2,0],[2,2,2,0],[4,5,2,1],[2,0,2,1],[0,1,3,1],[2,4,2,1]],"par":11},{"p":[[0,2,2,1],[2,4,3,1],[5,0,3,0],[0,0,2,0],[2,0,2,1],[0,4,2,0],[2,1,3,0],[4,3,2,1],[1,3,3,0],[2,5,2,1],[3,1,2,0]],"par":11},{"p":[[2,2,2,1],[0,5,2,1],[2,1,2,1],[4,4,2,1],[0,1,2,0],[3,3,2,0],[5,0,2,0],[2,4,2,0],[5,2,2,0],[1,1,2,0],[3,5,2,1],[1,3,2,1]],"par":11},{"p":[[0,2,2,1],[2,4,3,1],[5,0,3,0],[0,0,2,0],[2,0,2,1],[0,3,2,0],[2,1,3,0],[4,3,2,1],[1,3,3,0],[2,5,2,1],[3,2,2,0]],"par":11},{"p":[[0,2,2,1],[2,0,3,0],[3,0,2,0],[1,0,2,0],[2,4,3,1],[2,5,2,1],[5,3,2,0],[4,2,2,0],[0,3,3,0],[1,4,2,0],[5,1,2,0]],"par":11},{"p":[[0,2,2,1],[2,4,3,1],[5,2,3,0],[0,0,2,0],[2,0,2,1],[0,3,2,0],[2,1,3,0],[3,3,2,1],[1,3,3,0],[2,5,2,1],[3,1,2,0]],"par":11},{"p":[[0,2,2,1],[3,3,2,0],[4,4,2,1],[3,1,2,0],[1,1,2,1],[0,5,3,1],[4,0,2,1],[2,2,3,0],[4,2,2,0],[2,0,2,1]],"par":11},{"p":[[1,2,2,1],[4,1,3,0],[3,5,3,1],[2,3,2,1],[0,0,3,1],[5,0,2,0],[3,0,2,0],[3,4,3,1],[1,1,2,1],[2,4,2,0]],"par":12},{"p":[[3,2,2,1],[4,5,2,1],[1,2,2,0],[2,2,2,0],[3,0,2,1],[3,3,2,0],[5,0,3,0],[4,4,2,1],[0,3,3,0],[0,1,2,0],[1,5,3,1]],"par":12},{"p":[[0,2,2,1],[2,0,3,0],[3,2,2,0],[1,0,2,0],[2,4,3,1],[2,5,2,1],[5,4,2,0],[4,2,2,0],[0,3,3,0],[1,4,2,0],[5,2,2,0]],"par":12},{"p":[[1,2,2,1],[0,4,2,0],[3,5,3,1],[3,1,2,0],[3,0,2,1],[0,0,2,0],[3,4,2,1],[5,0,2,0],[5,2,2,0],[2,4,2,0],[2,0,2,0]],"par":12},{"p":[[0,2,2,1],[0,5,3,1],[3,4,2,0],[4,1,2,0],[1,3,2,0],[3,3,2,1],[4,4,2,0],[2,2,3,0],[1,1,2,1]],"par":12},{"p":[[1,2,2,1],[4,1,2,0],[3,4,3,1],[1,3,2,1],[3,1,3,0],[0,2,2,0],[2,4,2,0],[5,2,2,0],[0,0,2,0]],"par":12},{"p":[[0,2,2,1],[2,0,3,0],[3,2,2,0],[1,0,2,0],[2,4,3,1],[2,5,2,1],[5,4,2,0],[4,1,2,0],[0,3,3,0],[1,3,2,0],[5,2,2,0]],"par":12},{"p":[[0,2,2,1],[0,5,3,1],[3,4,2,0],[4,1,2,0],[1,3,2,0],[3,3,2,1],[4,4,2,0],[2,2,3,0],[2,1,2,1]],"par":12},{"p":[[3,2,2,1],[4,5,2,1],[1,1,2,0],[2,1,2,0],[0,0,2,1],[3,3,2,0],[5,0,3,0],[4,4,2,1],[0,3,3,0],[0,1,2,0],[1,5,3,1]],"par":12},{"p":[[1,2,2,1],[4,2,2,0],[3,4,3,1],[1,3,2,1],[3,1,3,0],[0,3,2,0],[2,4,2,0],[5,1,2,0],[0,1,2,0]],"par":12},{"p":[[1,2,2,1],[4,0,3,0],[3,5,3,1],[1,3,2,1],[0,0,3,1],[5,1,2,0],[3,2,2,0],[3,4,3,1],[1,1,2,1],[2,4,2,0]],"par":12},{"p":[[0,2,2,1],[2,4,2,1],[0,4,2,1],[4,0,2,1],[2,5,2,1],[2,0,2,1],[2,2,2,0],[0,0,2,0],[5,3,2,0],[1,0,2,0],[3,3,2,1],[4,4,2,0]],"par":12},{"p":[[0,2,2,1],[3,2,3,0],[4,1,2,0],[1,5,2,1],[1,4,2,1],[3,5,2,1],[0,4,2,0],[2,0,3,0],[3,0,3,1],[5,3,2,0],[0,1,2,1]],"par":12},{"p":[[1,2,2,1],[3,3,2,0],[4,4,2,1],[3,1,2,0],[1,1,2,1],[3,5,3,1],[2,0,2,1],[2,3,3,0],[4,0,2,0],[0,0,2,1]],"par":12},{"p":[[0,2,2,1],[0,4,2,0],[2,5,3,1],[3,2,2,0],[3,0,2,1],[0,0,2,0],[4,4,2,1],[5,0,2,0],[5,2,2,0],[2,2,2,0],[2,0,2,0]],"par":12},{"p":[[1,2,2,1],[4,1,2,0],[3,4,3,1],[1,3,2,1],[3,1,3,0],[0,3,2,0],[2,4,2,0],[5,2,2,0],[0,1,2,0]],"par":12},{"p":[[0,2,2,1],[2,0,2,1],[4,2,2,0],[4,0,2,0],[2,3,3,0],[5,1,2,0],[1,0,2,0],[2,1,2,0],[0,3,3,0]],"par":13},{"p":[[0,2,2,1],[3,2,3,0],[4,3,2,0],[1,5,2,1],[1,4,2,1],[3,5,2,1],[0,4,2,0],[2,1,3,0],[0,0,3,1],[5,2,2,0],[3,1,2,1]],"par":13},{"p":[[0,2,2,1],[2,4,2,1],[0,4,2,1],[4,0,2,1],[1,5,2,1],[2,0,2,1],[2,2,2,0],[0,0,2,0],[5,1,2,0],[1,0,2,0],[3,3,2,1],[4,4,2,0]],"par":13},{"p":[[1,2,2,1],[3,3,2,0],[0,0,3,0],[2,0,2,0],[3,0,2,1],[5,1,3,0],[1,0,2,0],[4,3,2,0],[4,1,2,0],[3,1,2,0]],"par":13},{"p":[[0,2,2,1],[5,4,2,0],[0,3,3,1],[1,0,2,0],[3,3,2,0],[3,5,2,1],[3,1,2,0],[2,0,2,1],[5,1,2,0],[0,5,2,1]],"par":14},{"p":[[1,2,2,1],[0,3,2,1],[2,4,2,1],[5,4,2,0],[3,2,2,0],[5,2,2,0],[0,0,3,0],[3,0,2,0],[2,0,2,0],[1,4,2,0]],"par":14},{"p":[[1,2,2,1],[5,2,2,0],[2,5,3,1],[2,0,2,0],[3,2,2,0],[1,3,2,1],[2,4,3,1],[1,4,2,0],[0,4,2,0],[5,4,2,0],[3,0,3,1]],"par":14},{"p":[[0,2,2,1],[0,4,2,0],[2,5,3,1],[3,1,2,0],[3,0,2,1],[0,0,2,0],[2,4,2,1],[5,1,2,0],[5,3,2,0],[2,2,2,0],[2,0,2,0]],"par":14},{"p":[[0,2,2,1],[5,0,2,0],[3,5,3,1],[2,1,2,0],[3,1,2,0],[3,3,2,1],[1,4,3,1],[1,0,2,0],[0,4,2,0],[5,2,2,0],[2,0,3,1]],"par":14},{"p":[[0,2,2,1],[3,2,3,0],[4,3,2,0],[1,5,2,1],[1,4,2,1],[3,5,2,1],[0,4,2,0],[2,0,3,0],[3,0,3,1],[5,4,2,0],[3,1,2,1]],"par":15},{"p":[[1,2,2,1],[1,3,2,1],[3,4,2,1],[5,4,2,0],[3,2,2,0],[5,1,2,0],[0,1,3,0],[3,0,2,0],[2,4,2,0],[1,4,2,0]],"par":15},{"p":[[0,2,2,1],[5,0,2,0],[0,5,3,1],[2,2,2,0],[3,1,2,0],[3,3,2,1],[3,4,3,1],[1,0,2,0],[0,3,2,0],[5,2,2,0],[2,0,3,1]],"par":15},{"p":[[0,2,2,1],[5,4,2,0],[0,3,3,1],[1,0,2,0],[3,3,2,0],[2,5,2,1],[3,1,2,0],[2,0,2,1],[5,0,2,0],[0,5,2,1]],"par":15},{"p":[[1,2,2,1],[0,4,3,1],[1,0,3,1],[3,2,3,0],[4,5,2,1],[0,2,2,0],[1,1,2,1],[4,0,2,1],[4,1,2,0],[4,3,2,1],[0,0,2,0]],"par":15},{"p":[[1,2,2,1],[5,2,2,0],[0,3,3,1],[1,0,2,0],[3,3,2,0],[3,5,2,1],[3,1,2,0],[2,0,2,1],[5,0,2,0],[0,5,2,1]],"par":15},{"p":[[1,2,2,1],[0,4,3,1],[1,0,3,1],[3,3,3,0],[0,5,2,1],[0,2,2,0],[1,1,2,1],[4,0,2,1],[4,1,2,0],[4,3,2,1],[0,0,2,0]],"par":15},{"p":[[0,2,2,1],[3,1,2,0],[4,1,2,0],[2,4,3,1],[0,0,2,0],[2,0,2,1],[5,1,3,0],[1,4,2,0],[3,3,2,1],[2,2,2,0],[4,0,2,1]],"par":15},{"p":[[0,2,2,1],[1,3,2,1],[3,4,2,1],[5,4,2,0],[3,2,2,0],[5,2,2,0],[0,3,3,0],[3,0,2,0],[2,4,2,0],[1,4,2,0]],"par":15},{"p":[[1,2,2,1],[4,4,2,1],[4,0,3,0],[2,0,2,0],[0,3,2,0],[2,4,2,0],[0,0,2,1],[5,2,2,0],[3,5,2,1],[5,0,2,0],[1,4,2,0]],"par":16},{"p":[[1,2,2,1],[0,4,3,1],[1,0,3,1],[3,2,3,0],[0,5,2,1],[0,2,2,0],[2,1,2,1],[4,0,2,1],[4,1,2,0],[4,3,2,1],[0,0,2,0]],"par":16},{"p":[[1,2,2,1],[3,2,2,0],[4,1,2,0],[3,4,3,1],[0,1,2,0],[1,0,2,1],[5,0,3,0],[1,4,2,0],[0,3,2,1],[2,3,2,0],[3,0,2,1]],"par":16},{"p":[[1,2,2,1],[3,4,2,1],[3,0,2,0],[0,1,2,0],[1,4,2,0],[2,4,2,0],[0,0,3,1],[5,4,2,0],[4,0,3,0]],"par":16},{"p":[[1,2,2,1],[5,2,2,0],[2,5,3,1],[2,0,2,0],[3,2,2,0],[0,3,2,1],[2,4,3,1],[1,4,2,0],[0,1,2,0],[5,4,2,0],[3,0,3,1]],"par":16},{"p":[[0,2,2,1],[5,1,2,0],[2,5,3,1],[2,1,2,0],[3,2,2,0],[4,3,2,1],[2,4,3,1],[1,3,2,0],[0,0,2,0],[5,4,2,0],[3,0,3,1]],"par":16},{"p":[[0,2,2,1],[3,1,2,0],[4,1,2,0],[2,4,3,1],[0,0,2,0],[1,0,2,1],[5,0,3,0],[1,3,2,0],[3,3,2,1],[2,2,2,0],[3,0,2,1]],"par":17},{"p":[[2,2,2,1],[3,4,2,1],[3,0,2,0],[0,1,2,0],[1,4,2,0],[2,3,2,0],[0,0,3,1],[5,4,2,0],[4,0,3,0]],"par":17},{"p":[[2,2,2,1],[4,4,2,1],[4,0,3,0],[2,0,2,0],[0,3,2,0],[2,4,2,0],[0,0,2,1],[5,2,2,0],[3,5,2,1],[5,0,2,0],[1,2,2,0]],"par":17},{"p":[[0,2,2,1],[3,1,2,0],[4,2,2,0],[3,4,3,1],[0,0,2,0],[1,0,2,1],[5,0,3,0],[1,4,2,0],[0,3,2,1],[2,4,2,0],[3,0,2,1]],"par":17},{"p":[[2,2,2,1],[3,4,2,1],[3,0,2,0],[0,1,2,0],[1,1,2,0],[2,3,2,0],[0,0,3,1],[5,4,2,0],[4,0,3,0]],"par":18},{"p":[[0,2,2,1],[3,2,2,0],[4,1,2,0],[2,4,3,1],[0,0,2,0],[2,0,2,1],[5,3,3,0],[1,4,2,0],[0,3,2,1],[2,2,2,0],[4,0,2,1]],"par":18},{"p":[[2,2,2,1],[3,4,2,1],[4,0,3,0],[2,0,2,0],[0,1,2,0],[2,3,2,0],[0,0,2,1],[5,3,2,0],[4,5,2,1],[5,1,2,0],[1,2,2,0]],"par":18},{"p":[[0,2,2,1],[3,2,2,0],[4,2,2,0],[2,4,3,1],[0,0,2,0],[1,0,2,1],[5,3,3,0],[1,4,2,0],[1,3,2,1],[2,1,2,0],[3,0,2,1]],"par":19}];
function unblock(el){
  const L=UB_LEVELS,CS=60,OFF=6,PS=30,PAL=['#f4a261','#2a9d8f','#e9c46a','#6c5ce7','#4cc9f0','#ef476f','#8ecae6','#90be6d','#b5838d'];
  el.innerHTML='<div class="bar" id="ubm" style="justify-content:center;margin:0"></div><div class="hud" id="ubs" aria-live="polite"></div><canvas width="384" height="372" tabindex="0"></canvas><div class="hud" id="ubb" style="flex-wrap:wrap;justify-content:center"></div><div id="ubx" style="max-width:420px;text-align:center"></div>';
  const cv=el.querySelector('canvas'),x=cv.getContext('2d');
  const store={get(k,d){try{const v=localStorage.getItem('be:'+k);return v?JSON.parse(v):d}catch(e){return d}},set(k,v){try{localStorage.setItem('be:'+k,JSON.stringify(v))}catch(e){}}};
  let pcs=[],hist=[],moves=0,mode='self',lv=0,cur=0,page=0,solved=false,anim=false,over=false,drag=null,hint=null,started=false,tleft=0,t0=0,timer=null,solvedN=0,seq=[],si=0,msg='',raf=0;
  let bestMoves=store.get('moves',{}),bestTimed=store.get('timed',0),bestSpeed=store.get('speed',0),used=new Set(store.get('used',[]));
  lv=Math.min(L.length-1,store.get('lv',0));
  const fmt=s=>{s=Math.max(0,s);const m=s/60|0;return m+':'+(s%60).toFixed(1).padStart(4,'0')};
  const NAMES={self:'Self-paced',timed:'Timed',speed:'Speed'};
  function pick(tpar){
    let pool=[];for(let i=0;i<L.length;i++)if(!used.has(i))pool.push(i);
    if(!pool.length){used.clear();pool=L.map((_,i)=>i)}
    const d=Math.min(...pool.map(i=>Math.abs(L[i].par-tpar))),near=pool.filter(i=>Math.abs(L[i].par-tpar)==d),i=near[Math.random()*near.length|0];
    used.add(i);store.set('used',[...used]);return i;
  }
  function grid(){const g=Array(36).fill(-1);pcs.forEach((p,i)=>{for(let k=0;k<p.l;k++)g[p.h?p.y*6+p.x+k:(p.y+k)*6+p.x]=i});return g}
  function span(i){const p=pcs[i],g=grid(),at=n=>p.h?g[p.y*6+n]:g[n*6+p.x];let lo=p.h?p.x:p.y,hi=lo;while(lo>0&&at(lo-1)<0)lo--;while(hi+p.l<6&&at(hi+p.l)<0)hi++;return[lo,hi]}
  function solve(){
    const n=pcs.length,fix=pcs.map(p=>p.h?p.y:p.x),len=pcs.map(p=>p.l),hz=pcs.map(p=>p.h),goal=6-pcs[0].l;
    const s0=pcs.map(p=>p.h?p.x:p.y),par=new Map([[s0.join(','),null]]);let q=[s0];
    while(q.length){const nq=[];
      for(const s of q){
        if(s[0]==goal){const path=[];let k=s.join(',');while(par.get(k)){const e=par.get(k);path.unshift({i:e.i,to:e.to});k=e.k}return path}
        const g=Array(36).fill(0);for(let i=0;i<n;i++)for(let j=0;j<len[i];j++)g[hz[i]?fix[i]*6+s[i]+j:(s[i]+j)*6+fix[i]]=1;
        for(let i=0;i<n;i++)for(const d of[-1,1]){
          let np=s[i]+d;
          while(np>=0&&np+len[i]<=6){
            const e=d<0?np:np+len[i]-1,cell=hz[i]?fix[i]*6+e:e*6+fix[i];if(g[cell])break;
            const t=s.slice();t[i]=np;const k=t.join(',');if(!par.has(k)){par.set(k,{k:s.join(','),i,to:np});nq.push(t)}np+=d;
          }
        }
      }q=nq}
    return null;
  }
  el._solve=solve;el._st=()=>({pcs,moves,mode,lv,cur,solved,over,solvedN,si,tleft,msg,used:used.size});
  function load(idx){cur=idx;if(mode=='self'){lv=idx;page=idx/PS|0;store.set('lv',lv)}pcs=L[idx].p.map(([px,py,l,h],k)=>({x:px,y:py,l,h:!!h,r:k==0}));hist=[];moves=0;solved=false;anim=false;hint=null;drag=null;draw();stat();btns()}
  function elapsed(){return started?(Date.now()-t0)/1000:0}
  function stat(){
    let t;
    if(mode=='self'){const b=bestMoves[lv];t=`Level ${lv+1} of ${L.length} · Moves ${moves} · Par ${L[lv].par}${b?' · Best '+b:''}`}
    else if(mode=='timed')t=`Time ${fmt(tleft)} · Solved ${solvedN} · Moves ${moves}`;
    else t=`Level ${Math.min(si+1,seq.length)} of ${seq.length} · Time ${fmt(elapsed())} · Moves ${moves}`;
    $('#ubs').textContent=t;
  }
  function btns(){
    const b=[['Undo','undo'],['Restart level','rst']];
    if(mode=='self'){b.push(['Hint','hint']);if(solved&&lv<L.length-1)b.push(['Next level','next'])}
    if(mode=='timed'&&!over)b.push(['New level (−10s)','skip']);
    if(over)b.push(['Play again','again']);
    $('#ubb').innerHTML=b.map(([t,k])=>`<button data-k="${k}">${t}</button>`).join('');
    $('#ubm').innerHTML=Object.keys(NAMES).map(k=>`<button class="chip" data-m="${k}" aria-pressed="${k==mode}">${NAMES[k]}</button>`).join('');
    let h='';
    if(mode=='self'){
      const pages=Math.ceil(L.length/PS),a=page*PS,sl=L.slice(a,a+PS);
      h=`<p class="empty" style="margin:8px 0">${msg||'Slide the blocks out of the way so the red block can exit on the right. Drag a block along its length.'}</p><div class="hud" style="justify-content:center;margin-bottom:6px"><button data-p="-1" ${page==0?'disabled':''}>‹</button><span>Levels ${a+1}–${a+sl.length} of ${L.length}</span><button data-p="1" ${page>=pages-1?'disabled':''}>›</button></div><div class="keys" style="max-width:420px;margin:0 auto">${sl.map((_,j)=>{const i=a+j;return`<button data-l="${i}" style="${i==lv?'outline:3px solid var(--accent)':''}">${bestMoves[i]?'★':i+1}</button>`}).join('')}</div>`;
    }
    else if(mode=='timed')h=`<p class="empty">${msg||'You have 3 minutes. Solve as many levels as you can. Every level is new and gets harder. The clock starts when you move a block.'}</p><p class="empty">Best: ${bestTimed||0} levels</p>`;
    else h=`<p class="empty">${msg||'Solve 5 new levels as fast as you can. The clock starts when you move a block.'}</p><p class="empty">Best: ${bestSpeed?fmt(bestSpeed):'none yet'}</p>`;
    $('#ubx').innerHTML=h;
  }
  function begin(){
    if(started||mode=='self')return;started=true;t0=Date.now();
    if(mode=='timed')timer=setInterval(()=>{tleft=Math.max(0,180-(Date.now()-t0)/1000);if(tleft<=0)endTimed();stat()},100);
    else timer=setInterval(stat,100);
  }
  function endTimed(){clearInterval(timer);over=true;if(solvedN>bestTimed){bestTimed=solvedN;store.set('timed',bestTimed)}msg=`Time\u2019s up! You solved ${solvedN} level${solvedN==1?'':'s'}.`;draw();btns();stat()}
  const tp=()=>Math.min(16,4+solvedN*.9);
  function start(m){
    clearInterval(timer);cancelAnimationFrame(raf);mode=m;over=false;started=false;msg='';solvedN=0;
    if(m=='self')load(lv);
    else if(m=='timed'){tleft=180;load(pick(4))}
    else{seq=[5,7,9,11,13].map(pick);si=0;load(seq[0])}
  }
  function onSolved(){
    if(mode=='self'){
      solved=true;const par=L[lv].par,st=moves<=par?3:moves<=par*1.5?2:1;
      if(!bestMoves[lv]||moves<bestMoves[lv]){bestMoves[lv]=moves;store.set('moves',bestMoves)}
      msg=`Solved in ${moves} moves (par ${par}). ${'★'.repeat(st)}${'☆'.repeat(3-st)}`;btns();stat();
    }else if(mode=='timed'){solvedN++;load(pick(tp()))}
    else{
      si++;
      if(si>=seq.length){
        clearInterval(timer);const t=elapsed();over=true;const nb=!bestSpeed||t<bestSpeed;
        if(nb){bestSpeed=t;store.set('speed',t)}
        msg=`Finished in ${fmt(t)}.`+(nb?' New best!':'');draw();btns();stat();
      }else load(seq[si]);
    }
  }
  function after(){
    hint=null;const r=pcs[0];
    if(r.x==6-r.l){anim=true;const go=()=>{r.fx=(r.fx??r.x)+.25;draw();if(r.fx<6.2)raf=requestAnimationFrame(go);else{r.fx=undefined;anim=false;onSolved()}};go()}
    else{draw();stat()}
  }
  function draw(){
    x.clearRect(0,0,384,372);
    x.fillStyle='#6b4a2b';x.beginPath();x.roundRect?x.roundRect(0,0,372,372,14):x.rect(0,0,372,372);x.fill();
    x.fillStyle='#e3c9a0';x.fillRect(OFF,OFF,360,360);
    x.strokeStyle='rgba(0,0,0,.12)';x.lineWidth=1;x.beginPath();for(let i=1;i<6;i++){x.moveTo(OFF+i*CS,OFF);x.lineTo(OFF+i*CS,OFF+360);x.moveTo(OFF,OFF+i*CS);x.lineTo(OFF+360,OFF+i*CS)}x.stroke();
    x.clearRect(372,OFF+2*CS+4,12,CS-8);x.fillStyle='#e3c9a0';x.fillRect(366,OFF+2*CS+4,6,CS-8);
    x.fillStyle='#2dc76d';x.beginPath();x.moveTo(372,OFF+2*CS+14);x.lineTo(384,OFF+2.5*CS);x.lineTo(372,OFF+3*CS-14);x.fill();
    pcs.forEach((p,i)=>{
      let px=p.x,py=p.y;if(p.fx!==undefined)px=p.fx;
      if(drag&&drag.i==i){if(p.h)px=drag.cur;else py=drag.cur}
      const w=(p.h?p.l:1)*CS-6,h=(p.h?1:p.l)*CS-6,X=OFF+px*CS+3,Y=OFF+py*CS+3;
      const col=p.r?'#e63946':PAL[i%PAL.length];
      x.save();x.shadowColor='rgba(0,0,0,.35)';x.shadowBlur=6;x.shadowOffsetY=2;x.fillStyle=col;x.beginPath();x.roundRect?x.roundRect(X,Y,w,h,10):x.rect(X,Y,w,h);x.fill();x.restore();
      x.fillStyle='rgba(255,255,255,.22)';x.fillRect(X+6,Y+5,Math.max(8,w-12),5);
      x.strokeStyle='rgba(0,0,0,.28)';x.lineWidth=2;x.beginPath();
      for(let k=1;k<p.l;k++){if(p.h){x.moveTo(X+k*CS-3,Y+10);x.lineTo(X+k*CS-3,Y+h-10)}else{x.moveTo(X+10,Y+k*CS-3);x.lineTo(X+w-10,Y+k*CS-3)}}x.stroke();
      if(p.r){x.fillStyle='#fff';x.beginPath();x.arc(X+w/2,Y+h/2,7,0,7);x.fill()}
      if(hint&&hint.i==i){x.strokeStyle='#fff';x.lineWidth=3;x.setLineDash([6,5]);x.strokeRect(X-1,Y-1,w+2,h+2);x.setLineDash([]);
        const to=hint.to,c0=p.h?p.x:p.y;x.fillStyle='#fff';x.font='800 22px sans-serif';x.textAlign='center';x.fillText(p.h?(to>c0?'▶':'◀'):(to>c0?'▼':'▲'),X+w/2,Y+h/2+8)}
    });
    if(over){x.fillStyle='rgba(0,0,0,.65)';x.fillRect(0,0,372,372);x.fillStyle='#fff';x.textAlign='center';x.font='800 26px sans-serif';x.fillText(mode=='timed'?'Time\u2019s up!':'Finished!',186,170);x.font='16px sans-serif';x.fillText(msg,186,200)}
  }
  const pt=e=>{const r=cv.getBoundingClientRect();return[(e.clientX-r.left)*cv.width/r.width,(e.clientY-r.top)*cv.height/r.height]};
  cv.addEventListener('pointerdown',e=>{
    if(solved||anim||over)return;const[px,py]=pt(e),cx=(px-OFF)/CS|0,cy=(py-OFF)/CS|0;if(px<OFF||py<OFF||cx>5||cy>5)return;
    const i=grid()[cy*6+cx];if(i<0)return;const p=pcs[i],[lo,hi]=span(i),s=p.h?p.x:p.y;
    drag={i,lo,hi,s,cur:s,off:(p.h?px:py)-s*CS};try{cv.setPointerCapture(e.pointerId)}catch(_){}draw();
  });
  cv.addEventListener('pointermove',e=>{
    if(!drag)return;const[px,py]=pt(e),p=pcs[drag.i];
    drag.cur=Math.max(drag.lo,Math.min(drag.hi,((p.h?px:py)-drag.off)/CS));draw();
  });
  const up=()=>{
    if(!drag)return;const d=drag,p=pcs[d.i],t=Math.round(d.cur);drag=null;
    if(t!=d.s){begin();hist.push({i:d.i,from:d.s});if(p.h)p.x=t;else p.y=t;moves++;after()}else draw();
  };
  cv.addEventListener('pointerup',up);cv.addEventListener('pointercancel',up);
  el.onclick=e=>{
    const m=e.target.closest('[data-m]');if(m){if(m.dataset.m!=mode)start(m.dataset.m);return}
    const pg=e.target.closest('[data-p]');if(pg){page=Math.max(0,Math.min(Math.ceil(L.length/PS)-1,page+ +pg.dataset.p));btns();return}
    const l=e.target.closest('[data-l]');if(l){if(mode=='self'){msg='';load(+l.dataset.l)}return}
    const b=e.target.closest('[data-k]');if(!b||anim)return;const k=b.dataset.k;
    if(k=='undo'){if(hist.length&&!over){const h=hist.pop(),p=pcs[h.i];if(p.h)p.x=h.from;else p.y=h.from;solved=false;hint=null;msg='';draw();stat();btns()}}
    else if(k=='rst'){if(!over){msg='';load(cur)}}
    else if(k=='hint'){const path=solve();if(path&&path.length){hint=path[0];msg='Hint: move the highlighted block in the direction shown.';draw();btns()}}
    else if(k=='next'){msg='';load(lv+1)}
    else if(k=='skip'){if(started)t0-=10000;load(pick(tp()))}
    else if(k=='again')start(mode);
  };
  start('self');
  return()=>{clearInterval(timer);cancelAnimationFrame(raf);el.onclick=null};
}
